import express from 'express';
import { db } from '@db';
import { properties, inspections, photos, reports, report_templates } from '@db/schema';
import { eq, desc } from 'drizzle-orm';
import PDFDocument from 'pdfkit';
import path from 'path';
import QRCode from 'qrcode';
import fs from 'fs';
import { format } from 'date-fns';

const router = express.Router();

router.get('/api/properties/:id/inspections/:inspectionId/report', async (req, res) => {
  try {
    console.log('Starting report generation...');
    const propertyId = parseInt(req.params.id);
    const inspectionId = parseInt(req.params.inspectionId);

    if (isNaN(propertyId) || isNaN(inspectionId)) {
      return res.status(400).json({ error: 'Invalid property or inspection ID' });
    }

    // Get inspection details
    const [inspection] = await db
      .select()
      .from(inspections)
      .where(eq(inspections.id, inspectionId))
      .limit(1);

    if (!inspection) {
      return res.status(404).json({ error: 'Inspection not found' });
    }

    // Get property details
    const [property] = await db
      .select()
      .from(properties)
      .where(eq(properties.id, propertyId))
      .limit(1);

    if (!property) {
      return res.status(404).json({ error: 'Property not found' });
    }

    // Get inspection photos
    const inspectionPhotos = await db
      .select()
      .from(photos)
      .where(eq(photos.propertyId, propertyId));

    console.log('Creating PDF document...');
    const doc = new PDFDocument({
      size: 'LETTER',
      margins: {
        top: 72,    // 1 inch margins
        bottom: 72,
        left: 72,
        right: 72
      },
      bufferPages: true,
      autoFirstPage: false
    });

    // Set up document event handlers
    const chunks: Buffer[] = [];
    doc.on('data', chunk => chunks.push(chunk));
    doc.on('end', () => {
      const pdfData = Buffer.concat(chunks);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="CloudLens-Assessment-${propertyId}-${format(new Date(), 'yyyy-MM-dd')}.pdf"`);
      res.send(pdfData);
      console.log('PDF generation completed successfully');
    });

    // Add header to each page
    const addHeader = () => {
      // Professional dark blue header bar
      doc.rect(0, 0, doc.page.width, 110)
         .fill('#0f172a');

      // Logo and company name
      doc.font('Helvetica-Bold')
         .fontSize(32)
         .fillColor('#ffffff')
         .text('CLOUDLENS™', 72, 35);

      // Report type with refined typography
      doc.fontSize(20)
         .font('Helvetica')
         .text('Aerial Storm Assessment Report', 72, 72);
    };

    // Add footer to each page
    const addFooter = (pageNumber: number) => {
      const totalPages = doc.bufferedPageRange().count;

      // Footer with subtle gradient background
      doc.rect(0, doc.page.height - 60, doc.page.width, 60)
         .fill('#f8fafc');

      // Footer content with refined typography
      doc.font('Helvetica')
         .fontSize(9)
         .fillColor('#475569');

      // Left side - Company info
      doc.text(
        'CloudLens™ Professional Assessment Services | 24/7 Support: 1-800-855-2562',
        72,
        doc.page.height - 40
      );

      // Right side - Page numbers
      doc.text(
        `Page ${pageNumber} of ${totalPages}`,
        doc.page.width - 150,
        doc.page.height - 40
      );
    };

    const addPropertyDetails = () => {
      doc.addPage();
      addHeader();

      // Property Information Section with elevated design
      doc.moveDown(4)
         .font('Helvetica-Bold')
         .fontSize(18)
         .fillColor('#0f172a')
         .text('PROPERTY DETAILS', { align: 'left' })
         .moveDown(1);

      // Create an info box with subtle background
      const boxWidth = doc.page.width - 2 * doc.page.margins.left;
      const boxY = doc.y;

      doc.rect(doc.x, boxY, boxWidth, 120)
         .fill('#f8fafc');

      doc.font('Helvetica')
         .fontSize(11)
         .fillColor('#334155');

      // Grid layout for property information
      const details = [
        { label: 'Property Address', value: property.address },
        { label: 'Location', value: `${property.city}, ${property.state} ${property.zipCode}` },
        { label: 'Assessment Date', value: format(new Date(), 'MMMM d, yyyy') },
        { label: 'Reference ID', value: `CL-${inspectionId.toString().padStart(6, '0')}` }
      ];

      const colWidth = boxWidth / 2;
      let currentY = boxY + 15;

      details.forEach((detail, index) => {
        const xPos = doc.x + (index % 2 === 0 ? 0 : colWidth);
        doc.font('Helvetica-Bold')
           .fontSize(10)
           .text(detail.label.toUpperCase(), xPos, currentY)
           .font('Helvetica')
           .fontSize(11)
           .text(detail.value, xPos, currentY + 20);

        if (index % 2 === 1) currentY += 60;
      });

      addFooter(1);
    };

    const addPhotoAnalysis = async (photo: any, index: number) => {
      doc.addPage();
      addHeader();

      doc.moveDown(4)
         .font('Helvetica-Bold')
         .fontSize(18)
         .fillColor('#0f172a')
         .text(index === 0 ? 'PRIMARY ASSESSMENT' : `SUPPLEMENTARY ANALYSIS ${index}`, { align: 'left' })
         .moveDown(1);

      if (photo.storageLocation) {
        try {
          const imagePath = path.join(process.cwd(), photo.storageLocation);
          if (fs.existsSync(imagePath)) {
            // Calculate optimal image dimensions
            const pageWidth = doc.page.width - 2 * doc.page.margins.left;
            const pageHeight = doc.page.height - doc.page.margins.top - doc.page.margins.bottom - 200;

            // Add image with border
            doc.rect(doc.x, doc.y, pageWidth, pageHeight)
               .stroke('#e2e8f0');

            doc.image(imagePath, {
              fit: [pageWidth - 20, pageHeight - 20],
              align: 'center',
              valign: 'center'
            });

            // Analysis box with professional styling
            if (photo.metadata) {
              const metadata = photo.metadata;
              const boxY = doc.y + 20;

              // Background for analysis box
              doc.rect(doc.x, boxY, pageWidth, 140)
                 .fill('#f1f5f9');

              // Title bar
              doc.rect(doc.x, boxY, pageWidth, 30)
                 .fill('#0f172a');

              doc.font('Helvetica-Bold')
                 .fontSize(14)
                 .fillColor('#ffffff')
                 .text('DAMAGE ASSESSMENT', doc.x + 20, boxY + 8);

              // Analysis content
              doc.font('Helvetica')
                 .fontSize(11)
                 .fillColor('#334155');

              const contentY = boxY + 40;
              const colWidth = (pageWidth - 40) / 2;

              // Left column
              doc.font('Helvetica-Bold')
                 .text('Damage Classification:', doc.x + 20, contentY)
                 .font('Helvetica')
                 .text(metadata.damageType || 'Not specified', doc.x + 20, contentY + 20);

              // Right column
              doc.font('Helvetica-Bold')
                 .text('Severity Level:', doc.x + colWidth + 20, contentY)
                 .font('Helvetica')
                 .text(metadata.severity || 'Not specified', doc.x + colWidth + 20, contentY + 20);

              // Notes section
              if (metadata.notes) {
                doc.font('Helvetica-Bold')
                   .text('Technical Analysis:', doc.x + 20, contentY + 50)
                   .font('Helvetica')
                   .text(metadata.notes, doc.x + 20, contentY + 70, {
                     width: pageWidth - 40,
                     align: 'left'
                   });
              }
            }
          }
        } catch (error) {
          console.error(`Error processing photo: ${error}`);
          doc.text('Error: Unable to load image', {
            align: 'center'
          });
        }
      }

      addFooter(index + 2);
    };

    const addQRCode = async () => {
      try {
        doc.addPage();
        addHeader();

        doc.moveDown(4)
           .font('Helvetica-Bold')
           .fontSize(18)
           .fillColor('#0f172a')
           .text('DIGITAL ACCESS', { align: 'center' })
           .moveDown(2);

        const shareableUrl = `${process.env.APP_URL}/report/${propertyId}`;
        const qrCodeDataUrl = await QRCode.toDataURL(shareableUrl);

        // Center the QR code with a border
        const qrSize = 200;
        const startX = (doc.page.width - qrSize) / 2;

        doc.rect(startX - 10, doc.y - 10, qrSize + 20, qrSize + 20)
           .stroke('#e2e8f0');

        doc.image(qrCodeDataUrl, startX, doc.y, {
          fit: [qrSize, qrSize]
        });

        // Add instructions with refined typography
        doc.moveDown(2)
           .font('Helvetica')
           .fontSize(12)
           .fillColor('#475569')
           .text('Scan this QR code to access the digital version of this report', {
             align: 'center'
           })
           .moveDown(0.5)
           .fontSize(10)
           .text('This report is also available online for easy sharing and archival', {
             align: 'center'
           });

        addFooter(doc.bufferedPageRange().count);
      } catch (error) {
        console.error('Error generating QR code:', error);
      }
    };

    // Generate the PDF content
    try {
      await addPropertyDetails();

      for (let i = 0; i < inspectionPhotos.length; i++) {
        await addPhotoAnalysis(inspectionPhotos[i], i);
      }

      await addQRCode();
      doc.end();

    } catch (error) {
      console.error('Error generating report content:', error);
      throw error;
    }

  } catch (error) {
    console.error('Error generating report:', error);
    res.status(500).json({ 
      error: 'Failed to generate report',
      details: error instanceof Error ? error.message : 'Unknown error'
    });
  }
});

export default router;