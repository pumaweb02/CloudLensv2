const { parentPort, workerData } = require('worker_threads');
const ExifParser = require('exif-parser');
const sharp = require('sharp');
const fs = require('fs/promises');
const path = require('path');
const { db } = require('../db');
const { photos, properties } = require('../db/schema');
const { eq } = require('drizzle-orm');
const fetch = require('node-fetch');

const UPLOAD_DIR = "uploads";
const THUMBNAIL_DIR = path.join(UPLOAD_DIR, "thumbnails");
const CHUNK_SIZE = 10 * 1024 * 1024; // 10MB chunks for processing
const MAX_CONCURRENT_PROCESSES = 3;
const REGRID_API_KEY = process.env.REGRID_API_KEY;

// Optimize Sharp configuration for high-volume processing
sharp.concurrency(2); // Limit concurrent processing
sharp.cache(50); // Increase cache size for batch processing
sharp.simd(true); // Enable SIMD optimization

// Memory management settings
sharp.queue.on('change', (queueLength) => {
  if (queueLength > 10) {
    console.log(`Warning: Sharp queue length: ${queueLength}`);
    global.gc && global.gc(); // Trigger garbage collection if available
  }
});

async function ensureDirectories() {
  await fs.mkdir(UPLOAD_DIR, { recursive: true }).catch(console.error);
  await fs.mkdir(THUMBNAIL_DIR, { recursive: true }).catch(console.error);
}

// ... [fetchPropertyData function remains unchanged] ...

// ... [createOrUpdateProperty function remains unchanged] ...

async function compressImage(buffer, options = {}) {
  const {
    quality = 85,
    maxWidth = 2048,
    maxHeight = 2048,
    preserveMetadata = true
  } = options;

  try {
    // Create Sharp instance with optimized settings
    const image = sharp(buffer, {
      failOnError: false,
      limitInputPixels: 268402689, // ~16K x 16K pixel limit
      sequentialRead: true // Better for large images
    });

    // Get original metadata
    const metadata = await image.metadata();

    // Calculate resize dimensions while maintaining aspect ratio
    let resizeOptions = {};
    if (metadata.width > maxWidth || metadata.height > maxHeight) {
      resizeOptions = {
        width: maxWidth,
        height: maxHeight,
        fit: 'inside',
        withoutEnlargement: true
      };
    }

    // Process image
    const processedImage = image
      .rotate() // Auto-rotate based on EXIF
      .resize(resizeOptions)
      .jpeg({
        quality,
        chromaSubsampling: '4:4:4', // Better quality
        progressive: true,
        force: true,
        mozjpeg: true, // Better compression
      });

    // Preserve metadata if requested
    if (preserveMetadata) {
      processedImage.withMetadata({
        orientation: metadata.orientation,
        exif: metadata.exif
      });
    }

    // Process and return buffer
    return await processedImage.toBuffer();
  } catch (error) {
    console.error('Error compressing image:', error);
    throw error;
  }
}

async function createThumbnail(buffer, filename) {
  const thumbnailFilename = `thumb-${path.basename(filename)}`;
  const thumbnailPath = path.join(THUMBNAIL_DIR, thumbnailFilename);

  try {
    await sharp(buffer, {
      failOnError: false,
      limitInputPixels: 268402689
    })
      .resize(300, 300, {
        fit: 'inside',
        withoutEnlargement: true
      })
      .jpeg({
        quality: 80,
        progressive: true,
        force: true
      })
      .toFile(thumbnailPath);

    return thumbnailPath;
  } catch (error) {
    console.error('Error creating thumbnail:', error);
    throw error;
  }
}

// ... [extractGPSData function remains unchanged] ...

async function processPhoto(file, userId) {
  let thumbnailPath = null;
  let originalMetadata = null;
  let propertyId = null;

  try {
    await ensureDirectories();
    console.log('Processing photo:', file.originalname);

    parentPort?.postMessage({
      type: 'progress',
      status: 'reading_file',
      progress: 10
    });

    // Read file
    const buffer = await fs.readFile(file.path);
    console.log('File read successfully');

    // Extract EXIF data before compression
    const exifData = ExifParser.create(buffer).parse();
    console.log('EXIF data extracted');

    // Validate GPS data
    const gpsData = extractGPSData(exifData);
    if (!gpsData) {
      throw new Error('No valid GPS data found in photo');
    }
    console.log('GPS data validated:', gpsData);

    // Compress image while preserving metadata
    console.log('Compressing image...');
    const processedImageBuffer = await compressImage(buffer, {
      quality: 85,
      maxWidth: 2048,
      maxHeight: 2048,
      preserveMetadata: true
    });

    // Save compressed image
    await fs.writeFile(file.path, processedImageBuffer);
    console.log('Processed image saved');

    // Generate thumbnail
    console.log('Generating thumbnail...');
    thumbnailPath = await createThumbnail(processedImageBuffer, file.filename);
    console.log('Thumbnail generated:', thumbnailPath);

    // Fetch property data and create/update property profile
    const propertyData = await fetchPropertyData(gpsData.latitude, gpsData.longitude);
    if (propertyData) {
      propertyId = await createOrUpdateProperty(propertyData);
      console.log('Property profile created/updated:', propertyId);
    } else {
      console.log('No property data found, creating minimal property record');
      propertyId = await createOrUpdateProperty({
        coordinates: {
          latitude: gpsData.latitude,
          longitude: gpsData.longitude
        },
        address: {
          street: `Unknown Location (${gpsData.latitude}, ${gpsData.longitude})`,
          city: 'Unknown',
          state: 'Unknown',
          zipCode: '00000'
        }
      });
    }

    // Get image metadata
    originalMetadata = await sharp(processedImageBuffer).metadata();

    // Update photo record
    await db
      .update(photos)
      .set({
        processingStatus: "processed",
        thumbnailPath: path.relative(UPLOAD_DIR, thumbnailPath),
        propertyId: propertyId,
        latitude: gpsData.latitude,
        longitude: gpsData.longitude,
        altitude: gpsData.altitude,
        metadata: {
          exif: exifData,
          imageMetadata: originalMetadata,
          gps: gpsData,
          property: propertyData,
          processing: {
            date: new Date().toISOString(),
            coordsQuality: 'high',
            compressionQuality: 85,
            originalSize: buffer.length,
            compressedSize: processedImageBuffer.length,
            compressionRatio: (buffer.length / processedImageBuffer.length).toFixed(2)
          }
        }
      })
      .where(eq(photos.id, file.id));

    console.log('Photo record updated successfully');

    parentPort?.postMessage({
      type: 'complete',
      photoId: file.id,
      thumbnailPath: path.relative(UPLOAD_DIR, thumbnailPath),
      propertyId: propertyId,
      results: {
        gps: gpsData,
        property: propertyData,
        metadata: originalMetadata,
        processedAt: new Date().toISOString(),
        compressionStats: {
          originalSize: buffer.length,
          compressedSize: processedImageBuffer.length,
          ratio: (buffer.length / processedImageBuffer.length).toFixed(2)
        }
      }
    });

  } catch (error) {
    console.error('Error processing photo:', error);

    await db
      .update(photos)
      .set({
        processingStatus: 'failed',
        metadata: {
          error: error.message,
          failedAt: new Date().toISOString(),
          originalMetadata: originalMetadata || null
        }
      })
      .where(eq(photos.id, file.id));

    if (thumbnailPath) {
      await fs.unlink(thumbnailPath).catch(console.error);
    }

    parentPort?.postMessage({
      type: 'error',
      error: error.message,
      details: {
        fileName: file.originalname,
        fileSize: file.size,
        mimeType: file.mimetype,
        metadata: originalMetadata
      }
    });
  }
}

// Start processing with timeout and memory monitoring
const processingTimeout = setTimeout(() => {
  console.error('Processing timeout exceeded');
  process.exit(1);
}, 300000); // 5 minutes timeout

// Monitor memory usage
setInterval(() => {
  const used = process.memoryUsage();
  if (used.heapUsed > 500 * 1024 * 1024) { // Alert if heap usage exceeds 500MB
    console.warn('High memory usage detected:', {
      heapUsed: `${Math.round(used.heapUsed / 1024 / 1024)} MB`,
      heapTotal: `${Math.round(used.heapTotal / 1024 / 1024)} MB`,
      rss: `${Math.round(used.rss / 1024 / 1024)} MB`
    });
    global.gc && global.gc(); // Trigger garbage collection if available
  }
}, 30000); // Check every 30 seconds

console.log('Starting photo processing:', workerData.file.originalname);

processPhoto(workerData.file, workerData.userId)
  .catch(error => {
    console.error('Worker critical error:', error);
    parentPort?.postMessage({
      type: 'error',
      error: error.message,
      critical: true
    });
  })
  .finally(() => {
    clearTimeout(processingTimeout);
  });