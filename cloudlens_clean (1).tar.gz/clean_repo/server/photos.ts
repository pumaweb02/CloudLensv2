import fs from "fs/promises";
import path from "path";
import ExifParser from "exif-parser";
import { photos } from "@db/schema";
import { db } from "@db";
import { eq } from "drizzle-orm";

// Define upload directory - ensure it exists
const UPLOAD_DIR = "uploads";

// Ensure upload directory exists
async function ensureUploadDir() {
  try {
    await fs.access(UPLOAD_DIR);
  } catch {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
  }
}

// Initialize storage
ensureUploadDir().catch(console.error);

export const photoUtils = {
  /**
   * Get the full path for a stored photo
   */
  getPhotoPath(filename: string): string {
    return path.join(UPLOAD_DIR, filename);
  },

  /**
   * Delete a photo file from storage
   */
  async deletePhoto(filename: string): Promise<void> {
    const filepath = this.getPhotoPath(filename);
    try {
      await fs.unlink(filepath);
    } catch (error) {
      console.error(`Error deleting photo ${filename}:`, error);
      throw error;
    }
  },

  /**
   * Save photo metadata to database
   */
  async savePhotoMetadata(data: {
    filename: string;
    originalName: string;
    mimeType: string;
    size: number;
    userId: number;
    propertyId: number;
    batchId?: number | null;
    metadata: any;
    gpsData?: {
      latitude?: number | null;
      longitude?: number | null;
      altitude?: number | null;
    };
  }) {
    try {
      // Extract GPS data if available
      const { latitude, longitude, altitude } = data.gpsData || {};

      // Save to database with proper types
      const [photo] = await db
        .insert(photos)
        .values({
          filename: data.filename,
          originalName: data.originalName,
          mimeType: data.mimeType,
          size: data.size,
          userId: data.userId,
          propertyId: data.propertyId,
          batchId: data.batchId || null,
          metadata: data.metadata,
          latitude: latitude || null,
          longitude: longitude || null,
          altitude: altitude || null,
          processingStatus: "completed",
          storageLocation: path.join(UPLOAD_DIR, data.filename),
          uploadedAt: new Date()
        })
        .returning();

      return photo;
    } catch (error) {
      console.error('Error saving photo metadata:', error);
      throw error;
    }
  },

  /**
   * Extract GPS coordinates from EXIF data
   */
  async readExifData(filepath: string): Promise<ExifParser.Output | null> {
    try {
      const buffer = await fs.readFile(filepath);
      const parser = ExifParser.create(buffer);
      return parser.parse();
    } catch (error) {
      console.error(`Error reading EXIF data from ${filepath}:`, error);
      return null;
    }
  },

  /**
   * Get photo details from database
   */
  async getPhotoDetails(photoId: number) {
    const [photo] = await db
      .select()
      .from(photos)
      .where(eq(photos.id, photoId));
    return photo;
  },

  /**
   * Get all photos for a property
   */
  async getPropertyPhotos(propertyId: number) {
    const propertyPhotos = await db
      .select()
      .from(photos)
      .where(eq(photos.propertyId, propertyId));
    return propertyPhotos;
  },

  /**
   * Get MIME type from filename
   */
  getMimeType(filename: string): string {
    const ext = path.extname(filename).toLowerCase();
    switch (ext) {
      case '.jpg':
      case '.jpeg':
        return 'image/jpeg';
      case '.png':
        return 'image/png';
      case '.tiff':
      case '.tif':
        return 'image/tiff';
      case '.heic':
        return 'image/heic';
      case '.raw':
        return 'image/raw';
      default:
        return 'application/octet-stream';
    }
  },

  /**
   * Delete photo record and file
   */
  async deletePhotoRecord(photoId: number): Promise<boolean> {
    try {
      const [photo] = await db
        .select()
        .from(photos)
        .where(eq(photos.id, photoId));

      if (!photo) {
        return false;
      }

      // Delete the file first
      await this.deletePhoto(photo.filename);

      // Then remove from database
      await db
        .delete(photos)
        .where(eq(photos.id, photoId));

      return true;
    } catch (error) {
      console.error(`Error deleting photo ${photoId}:`, error);
      return false;
    }
  },
  /**
   * Validate file type
   */
  isValidFileType(mimeType: string): boolean {
    const validTypes = [
      'image/jpeg',
      'image/png',
      'image/tiff',
      'image/heic',
      'image/raw'
    ];
    return validTypes.includes(mimeType);
  },

  /**
   * Extract GPS coordinates from EXIF data
   */
  extractGpsCoordinates(exif: ExifParser.Output): { latitude: number | null; longitude: number | null; altitude: number | null } {
    try {
      const { latitude, longitude, gpsAltitude } = exif.tags;
      return {
        latitude: typeof latitude === 'number' ? latitude : null,
        longitude: typeof longitude === 'number' ? longitude : null,
        altitude: typeof gpsAltitude === 'number' ? gpsAltitude : null
      };
    } catch (error) {
      console.error('Error extracting GPS coordinates:', error);
      return { latitude: null, longitude: null, altitude: null };
    }
  },
  /**
   * Clean up orphaned files
   * This can be run periodically to remove files without DB entries
   */
  async cleanupOrphanedFiles(): Promise<number> {
    try {
      const files = await fs.readdir(UPLOAD_DIR);
      let removed = 0;

      for (const file of files) {
        const [photo] = await db
          .select()
          .from(photos)
          .where(eq(photos.filename, file));

        if (!photo) {
          await fs.unlink(path.join(UPLOAD_DIR, file));
          removed++;
        }
      }

      return removed;
    } catch (error) {
      console.error('Error cleaning up orphaned files:', error);
      return 0;
    }
  }
};