/**
 * Photo Matching Module
 * 
 * Handles the automated matching of uploaded photos to properties using:
 * - GPS coordinates validation
 * - Batch processing
 * - Monte Carlo enhanced matching algorithm
 * 
 * @module PhotoMatching
 */

import { db } from "@db";  // Using the configured alias
import { photos, properties } from "@db/schema";
import { eq, and, isNull } from "drizzle-orm";
import { validateWGS84Coordinates } from "../../client/src/lib/coordinates";
import { PhotoMatcher } from "../lib/photo-matcher";

// Type definitions
interface MatchResult {
  propertyId?: number;
  confidence: number;
  matchMethod: string;
  matchFactors?: {
    gpsAccuracy?: number;
    addressSimilarity?: number;
    temporalConsistency?: number;
    [key: string]: number | undefined;
  };
}

// Configuration constants
/** Number of photos to process in each batch */
const BATCH_SIZE = 50;
/** Maximum number of processing retries per photo */
const MAX_RETRIES = 3;
/** Delay between processing individual photos (ms) */
const DELAY_BETWEEN_PHOTOS = 300;

// Initialize photo matcher with default configuration
const photoMatcher = new PhotoMatcher({
  confidenceThreshold: 0.8,
  maxDistance: 100, // meters
  temporalWindowSize: 3600 // 1 hour in seconds
});

/**
 * Process a batch of unassigned photos using enhanced Monte Carlo matching
 * 
 * This function:
 * 1. Retrieves unassigned photos from the database
 * 2. Validates GPS coordinates
 * 3. Attempts to match photos to properties
 * 4. Updates the database with results
 * 
 * @async
 * @returns {Promise<void>}
 */
async function processUnassignedPhotos(): Promise<void> {
  try {
    // Get batch of unassigned photos
    const unassignedPhotos = await db
      .select()
      .from(photos)
      .where(
        and(
          isNull(photos.propertyId),
          eq(photos.processingStatus, 'pending')
        )
      )
      .limit(BATCH_SIZE);

    if (unassignedPhotos.length === 0) {
      console.log("No unassigned photos to process");
      return;
    }

    console.log(`Processing ${unassignedPhotos.length} unassigned photos with Monte Carlo enhanced matching`);

    // Process each photo in the batch
    for (const photo of unassignedPhotos) {
      try {
        console.log(`\nProcessing photo ${photo.id}:`);

        // Validate GPS data availability
        if (!photo.metadata?.gps) {
          console.log(`- No GPS data available`);
          await db
            .update(photos)
            .set({ 
              processingStatus: 'failed', 
              processingError: 'No GPS data',
              matchMethod: 'missing_gps'
            })
            .where(eq(photos.id, photo.id));
          continue;
        }

        // Validate GPS coordinates
        const photoCoords = validateWGS84Coordinates(
          photo.metadata.gps.latitude,
          photo.metadata.gps.longitude
        );

        if (!photoCoords) {
          console.log(`- Invalid GPS coordinates detected`);
          await db
            .update(photos)
            .set({ 
              processingStatus: 'failed', 
              processingError: 'Invalid GPS coordinates',
              matchMethod: 'invalid_gps'
            })
            .where(eq(photos.id, photo.id));
          continue;
        }

        console.log(`- GPS Coordinates: ${photoCoords.latitude}, ${photoCoords.longitude}`);

        // Get related batch photos for context
        const batchPhotos = photo.batchId ? 
          await db.select()
            .from(photos)
            .where(eq(photos.batchId, photo.batchId)) : 
          [];

        if (batchPhotos.length > 0) {
          console.log(`- Found ${batchPhotos.length} related photos in batch ${photo.batchId}`);
        }

        // Attempt property matching
        console.log('- Running Monte Carlo enhanced matching...');
        const matchResult = await photoMatcher.findMatchingProperty(photo, batchPhotos);

        if (matchResult.propertyId) {
          // Update photo with successful match
          await db
            .update(photos)
            .set({
              propertyId: matchResult.propertyId,
              propertyMatchConfidence: matchResult.confidence,
              matchMethod: matchResult.matchMethod,
              matchFactors: matchResult.matchFactors,
              processingStatus: 'processed',
              processingError: null
            })
            .where(eq(photos.id, photo.id));

          console.log(`✓ Matched to property ${matchResult.propertyId} with confidence ${matchResult.confidence}`);
          if (matchResult.matchFactors) {
            console.log('  Match factors:', matchResult.matchFactors);
          }
        } else {
          // Update photo as requiring manual review
          await db
            .update(photos)
            .set({
              processingStatus: 'manual_review_required',
              processingError: `No match found: ${matchResult.matchMethod}`,
              matchMethod: matchResult.matchMethod,
              matchFactors: matchResult.matchFactors
            })
            .where(eq(photos.id, photo.id));

          console.log(`× No confident match found - marked for review (${matchResult.matchMethod})`);
        }

      } catch (error) {
        console.error(`Error processing photo ${photo.id}:`, error);

        // Update retry count and status
        const retryCount = (photo.processingRetries || 0) + 1;
        await db
          .update(photos)
          .set({
            processingRetries: retryCount,
            processingStatus: retryCount >= MAX_RETRIES ? 'failed' : 'pending',
            processingError: error instanceof Error ? error.message : String(error),
            matchMethod: 'error'
          })
          .where(eq(photos.id, photo.id));

        console.log(`! Processing failed (attempt ${retryCount}/${MAX_RETRIES})`);
      }

      // Add delay between photos to prevent API rate limiting
      await new Promise(resolve => setTimeout(resolve, DELAY_BETWEEN_PHOTOS));
    }
  } catch (error) {
    console.error("Error in processUnassignedPhotos:", error);
  }
}

// Export for scheduling system
export { processUnassignedPhotos };