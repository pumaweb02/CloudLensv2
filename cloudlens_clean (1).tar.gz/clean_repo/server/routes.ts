import type { Express, Request, Response, NextFunction } from "express";
import { Client as GoogleMapsClient } from "@googlemaps/google-maps-services-js";
import type { AddressType, PlaceAutocompleteType } from "@googlemaps/google-maps-services-js";
import type { SQL } from "drizzle-orm";
import type { PgColumn } from "drizzle-orm/pg-core";
import { createServer } from 'http';
import multer from "multer";
import path from "path";
import { db } from "@db";
import {
  photos,
  type Photo,
  scan_batches,
  properties,
  user_preferences,
  weather_events,
  affected_properties,
  inspections,
  users,
  reports
} from "@db/schema";
import { eq, sql, desc, and, or } from "drizzle-orm";
import ExifReader from "exifreader";
import { promises as fs } from "fs";
import express from "express";
import { imageProcessor } from './image-processing';
import axios from 'axios';
import { z } from "zod";
import { Worker } from 'worker_threads';
import propertiesRouter from './routes/properties';
import { setupAuth } from './auth';
import { generateInspectionReport } from '../client/src/lib/pdf-generation';

// Initialize Google Maps client
const googleMapsClient = new GoogleMapsClient({});

// Add proper type for authenticated request
interface AuthenticatedRequest extends Request {
  user?: {
    id: number;
    username: string;
    role: "admin" | "user";
  };
}

interface GPSData {
  latitude: number;
  longitude: number;
  altitude: number | null;
}

interface ExifMetadata {
  gps?: GPSData;
  DateTimeOriginal?: string | null;
}

interface AddressDetails {
  address: string;
  city: string;
  state: string;
  zipCode: string;
}


// Tomorrow.io API types and configuration
interface TomorrowioParams {
  location: string;
  fields: string[];
  units: string;
  apikey: string;
}

interface TomorrowioResponse {
  data: {
    timelines: Array<{
      timestep: string;
      endTime: string;
      startTime: string;
      intervals: Array<{
        startTime: string;
        values: {
          temperature: number;
          temperatureApparent: number;
          humidity: number;
          precipitationIntensity: number;
          precipitationType: number;
          pressureSurfaceLevel: number;
          visibility: number;
          weatherCode: number;
          windSpeed: number;
          windDirection: number;
          hailIntensity?: number;
          hailProbability?: number;
        };
      }>;
    }>;
  };
  location: {
    lat: number;
    lon: number;
    name: string | null;
  };
}

// Constants and Configuration 
const UPLOAD_DIR = "uploads";
const CHUNK_DIR = path.join(UPLOAD_DIR, "chunks");
const THUMBNAIL_DIR = path.join(UPLOAD_DIR, "thumbnails");
const MAX_CHUNK_SIZE = 50 * 1024 * 1024; // Increased to 50MB chunks for better performance
const BATCH_SIZE = 20; // Process 20 files at a time
const PROCESSING_QUEUE: any[] = [];
let isProcessing = false;

// Create necessary directories if they don't exist
Promise.all([
  fs.mkdir(UPLOAD_DIR, { recursive: true }),
  fs.mkdir(CHUNK_DIR, { recursive: true }),
  fs.mkdir(THUMBNAIL_DIR, { recursive: true })
]).catch(console.error);

const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    // Store chunks in separate directories by file
    if (req.body.isChunked === 'true') {
      const chunkDir = path.join(CHUNK_DIR, path.basename(file.originalname, path.extname(file.originalname)));
      await fs.mkdir(chunkDir, { recursive: true });
      cb(null, chunkDir);
    } else {
      cb(null, UPLOAD_DIR);
    }
  },
  filename: (req, file, cb) => {
    if (req.body.isChunked === 'true') {
      // For chunks, use chunk number as filename
      cb(null, `chunk-${req.body.chunkIndex}`);
    } else {
      const ext = path.extname(file.originalname);
      const sanitizedName = file.originalname.replace(ext, '').replace(/[^a-zA-Z0-9]/g, '-');
      const filename = `${Date.now()}-${sanitizedName}${ext}`;
      cb(null, filename);
    }
  }
});

// Separate upload middleware for images with increased limits
const imageUpload = multer({
  storage: storage,
  limits: {
    fileSize: req => req.body.isChunked === 'true' ? MAX_CHUNK_SIZE : 5 * 1024 * 1024 * 1024, // 5GB for direct uploads
    files: 5000
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      "image/jpeg",
      "image/png",
      "image/tiff",
      "image/heic",
      "image/raw"
    ];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type: ${file.mimetype}. Only JPEG, PNG, TIFF, HEIC, and RAW formats are allowed.`));
    }
  }
});

// Separate upload middleware for PDFs
const pdfUpload = multer({
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit for PDFs
    files: 1
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed."));
    }
  }
});

// Helper Functions
async function geocodeCoordinates(latitude: number, longitude: number): Promise<AddressDetails | null> {
  if (!process.env.GOOGLE_MAPS_API_KEY) {
    console.warn("Google Maps API key not configured. Address geocoding disabled.");
    return null;
  }

  try {
    const response = await googleMapsClient.reverseGeocode({
      params: {
        latlng: { lat: latitude, lng: longitude },
        key: process.env.GOOGLE_MAPS_API_KEY,
        result_type: ["street_address", "premise"] as AddressType[],
      },
    });

    if (response.data.status !== "OK" || !response.data.results[0]) {
      console.warn("No geocoding results found for coordinates:", { latitude, longitude });
      return null;
    }

    const result = response.data.results[0];
    const addressComponents = result.address_components;

    let streetNumber = "", route = "", city = "", state = "", zipCode = "";

    for (const component of addressComponents) {
      const types = component.types as AddressType[];
      if (types.includes("street_number" as AddressType)) {
        streetNumber = component.long_name;
      } else if (types.includes("route" as AddressType)) {
        route = component.long_name;
      } else if (types.includes("locality" as AddressType)) {
        city = component.long_name;
      } else if (types.includes("administrative_area_level_1" as AddressType)) {
        state = component.short_name;
      } else if (types.includes("postal_code" as AddressType)) {
        zipCode = component.long_name;
      }
    }

    if (!state) state = "GA";

    return {
      address: streetNumber && route ? `${streetNumber} ${route}` : result.formatted_address,
      city: city || "Unknown",
      state,
      zipCode: zipCode || "Unknown"
    };
  } catch (error) {
    console.error("Geocoding error:", error);
    return null;
  }
}

function formatAltitude(altitude: number | null, unit: string): string | null {
  if (altitude === null) return null;
  const altitudeValue = unit === 'meters' ? Math.round(altitude / 3.28084) : altitude;
  return `${altitudeValue} ${unit} above sea level`;
}

function extractGPSData(tags: ExifReader.Tags): GPSData | null {
  try {
    if (!tags['GPSLatitude'] || !tags['GPSLongitude']) {
      console.log("Missing required GPS tags");
      return null;
    }

    let latitude: number | null = null;
    let longitude: number | null = null;
    let altitude: number | null = null;

    const dmsToDecimal = (degrees: number, minutes: number, seconds: number): number => {
      return degrees + (minutes / 60.0) + (seconds / 3600.0);
    };

    // Handle latitude with proper type checking
    if (tags['GPSLatitude']?.description) {
      latitude = parseFloat(String(tags['GPSLatitude'].description));
    } else if (Array.isArray(tags['GPSLatitude']?.value)) {
      const dmsValues = (tags['GPSLatitude'].value as any[]).map((v: any) => v.numerator / v.denominator);
      latitude = dmsToDecimal(dmsValues[0], dmsValues[1], dmsValues[2]);
    }

    if (tags['GPSLatitudeRef']?.value && String(tags['GPSLatitudeRef'].value)[0] === 'S' && latitude !== null) {
      latitude = -latitude;
    }

    // Handle longitude with proper type checking
    if (tags['GPSLongitude']?.description) {
      longitude = parseFloat(String(tags['GPSLongitude'].description));
    } else if (Array.isArray(tags['GPSLongitude']?.value)) {
      const dmsValues = (tags['GPSLongitude'].value as any[]).map((v: any) => v.numerator / v.denominator);
      longitude = dmsToDecimal(dmsValues[0], dmsValues[1], dmsValues[2]);
    }

    if (tags['GPSLongitudeRef']?.value && String(tags['GPSLongitudeRef'].value)[0] === 'W' && longitude !== null) {
      longitude = -longitude;
    }

    // Handle altitude with proper numeric conversion
    if (tags['GPSAltitude']) {
      const altValue = tags['GPSAltitude'].description;
      if (typeof altValue === 'string' && altValue.includes(' ')) {
        altitude = parseFloat(altValue.split(' ')[0]); // Extract numeric value only
      } else if (!isNaN(Number(altValue))) {
        altitude = Number(altValue);
      }
    }

    if (latitude === null || longitude === null || isNaN(latitude) || isNaN(longitude)) {
      console.log("Failed to convert GPS coordinates");
      return null;
    }

    latitude = Number(latitude.toFixed(6));
    longitude = Number(longitude.toFixed(6));

    return {
      latitude,
      longitude,
      altitude
    };
  } catch (error) {
    console.error("Error extracting GPS data:", error);
    return null;
  }
}

function parseTimestamp(tags: ExifReader.Tags): string | null {
  const dateTimeOriginal = tags['DateTimeOriginal']?.description;
  const createDate = tags['CreateDate']?.description;
  const dateStr = dateTimeOriginal || createDate;

  if (dateStr) {
    try {
      const match = dateStr.match(/(\d{4}):(\d{2}):(\d{2}) (\d{2}):(\d{2}):(\d{2})/);
      if (match) {
        const [_, year, month, day, hour, minute, second] = match;
        const utcDate = new Date(Date.UTC(
          parseInt(year),
          parseInt(month) - 1,
          parseInt(day),
          parseInt(hour),
          parseInt(minute),
          parseInt(second)
        ));
        return utcDate.toISOString();
      }
    } catch (error) {
      console.error("Error parsing timestamp:", error);
    }
  }
  return null;
}

async function savePhotoToDatabase(
  file: Express.Multer.File,
  propertyId: number | null,
  userId: number,
  metadata: any,
  batchId: number,
  thumbnailPath: string | null = null
): Promise<Photo> {
  try {
    const [photo] = await db
      .insert(photos)
      .values({
        propertyId,
        userId,
        batchId,
        filename: file.filename,
        originalName: file.originalname,
        mimeType: file.mimetype,
        size: file.size,
        latitude: metadata.gps?.latitude || null,
        longitude: metadata.gps?.longitude || null,
        altitude: metadata.gps?.altitude || null,
        takenAt: metadata.DateTimeOriginal ? new Date(metadata.DateTimeOriginal) : null,
        metadata: metadata,
        storageLocation: path.join(UPLOAD_DIR, file.filename),
        thumbnailPath: thumbnailPath,
        processingStatus: "pending"
      })
      .returning();

    if (!photo) {
      throw new Error('Failed to save photo to database');
    }

    return photo;
  } catch (error) {
    console.error('Error saving photo to database:', error);
    throw error;
  }
}

// Helper function to generate Street View image URL using full address
function getStreetViewImageUrl(addressDetails: AddressDetails, apiKey: string): string {
  const fullAddress = `${addressDetails.address}, ${addressDetails.city}, ${addressDetails.state} ${addressDetails.zipCode}`;
  const encodedAddress = encodeURIComponent(fullAddress);
  return `https://maps.googleapis.com/maps/api/streetview?size=600x400&location=${encodedAddress}&key=${apiKey}`;
}

// Enhanced address normalization with more robust cleaning
function normalizeAddress(address: string): string {
  return address
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim()
    // Remove all special characters except numbers and letters
    .replace(/[^\w\s0-9]/g, '')
    // Remove directional prefixes
    .replace(/^(north|south|east|west|n|s|e|w)\s+/i, '')
    // Standardize common abbreviations
    .replace(/\b(street|str|st)\b/gi, 'st')
    .replace(/\b(avenue|ave)\b/gi, 'ave')
    .replace(/\b(road|rd)\b/gi, 'rd')
    .replace(/\b(drive|dr)\b/gi, 'dr')
    .replace(/\b(lane|ln)\b/gi, 'ln')
    .replace(/\b(boulevard|blvd)\b/gi, 'blvd')
    .replace(/\b(court|ct)\b/gi, 'ct')
    .replace(/\b(circle|cir)\b/gi, 'cir')
    .replace(/\b(parkway|pkwy)\b/gi, 'pkwy')
    .replace(/\b(place|pl)\b/gi, 'pl')
    .replace(/\b(square|sq)\b/gi, 'sq')
    .replace(/\b(terrace|ter)\b/gi, 'ter')
    .replace(/\b(trail|trl)\b/gi, 'trl')
    .replace(/\b(way)\b/gi, 'way')
    // Remove unit/suite numbers
    .replace(/(?:unit|apt|apartment|suite|ste|#)\s*[\w-]+/gi, '')
    // Remove floor indicators
    .replace(/(?:\d+(?:st|nd|rd|th)\s+(?:floor|fl))/gi, '')
    // Keep the numbers but remove ordinal suffixes
    .replace(/(\d+)(?:st|nd|rd|th)/g, '$1')
    // Remove all spaces
    .replace(/\s+/g, '')
    .trim();
}

// Calculate Levenshtein distance for fuzzy matching
function levenshteinDistance(a: string, b: string): number {
  if (a.length === 0) return b.length;
  if (b.length === 0) return a.length;

  const matrix = [];

  for (let i = 0; i <= b.length; i++) {
    matrix[i] = [i];
  }

  for (let j = 0; j <= a.length; j++) {
    matrix[0][j] = j;
  }

  for (let i = 1; i <= b.length; i++) {
    for (let j = 1; j <= a.length; j++) {
      if (b.charAt(i - 1) === a.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          Math.min(
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          )
        );
      }
    }
  }

  return matrix[b.length][a.length];
}

// Enhanced property matching and creation
async function findOrCreateProperty(
  gpsData: GPSData,
  userId: number
): Promise<number> {
  try {
    console.log("Finding or creating property with GPS coordinates:", gpsData);

    // First get address from coordinates
    const addressDetails = await geocodeCoordinates(gpsData.latitude, gpsData.longitude);
    if (!addressDetails) {
      console.warn("Could not geocode coordinates:", gpsData);
      throw new Error("Failed to geocode coordinates");
    }

    console.log("Geocoded address details:", addressDetails);

    // Normalize the new address for comparison
    const normalizedNewAddress = normalizeAddress(addressDetails.address);
    console.log("Normalized new address:", normalizedNewAddress);

    // First try exact address match with extended search
    const existingProperties = await db
      .select()
      .from(properties)
      .where(
        and(
          eq(properties.city, addressDetails.city),
          eq(properties.state, addressDetails.state),
          eq(properties.zipCode, addressDetails.zipCode),
          eq(properties.isDeleted, false)
        )
      );

    console.log(`Found ${existingProperties.length} properties in same city/state/zip`);

    // Check for exact or very close matches first
    for (const property of existingProperties) {
      const normalizedExisting = normalizeAddress(property.address);

      // Log each comparison for debugging
      console.log(`Comparing addresses:
        Original: ${property.address} vs ${addressDetails.address}
        Normalized: ${normalizedExisting} vs ${normalizedNewAddress}
      `);

      // Check for exact match after normalization
      if (normalizedExisting === normalizedNewAddress) {
        console.log("Found exact match after normalization:", property);
        return property.id;
      }

      // Calculate similarity score
      const distance = levenshteinDistance(normalizedExisting, normalizedNewAddress);
      const maxLength = Math.max(normalizedExisting.length, normalizedNewAddress.length);
      const similarity = 1 - (distance / maxLength);

      console.log(`Address similarity score: ${similarity}`);

      // If addresses are very similar (90% or more similar)
      if (similarity >= 0.9) {
        console.log("Found very similar address:", property);
        return property.id;
      }
    }

    // If no match found by address, check nearby properties
    // Reduce search radius to 25 meters for dense communities
    const nearbyProperties = await db
      .select()
      .from(properties)
      .where(
        and(
          sql`ST_DWithin(
            ST_MakePoint(${gpsData.latitude}, ${gpsData.longitude})::geography,
            ST_MakePoint(latitude, longitude)::geography,
            25
          )`,
          eq(properties.isDeleted, false)
        )
      );

    if (nearbyProperties.length > 0) {
      console.log(`Found ${nearbyProperties.length} nearby properties`);

      // For nearby properties, prioritize house number matching
      const nearbyMatch = nearbyProperties.find(prop => {
        const normalizedExisting = normalizeAddress(prop.address);
        const existingNumber = prop.address.match(/^\d+/)?.[0];
        const newNumber = addressDetails.address.match(/^\d+/)?.[0];

        // If house numbers match exactly, be more lenient with overall similarity
        if (existingNumber && newNumber && existingNumber === newNumber) {
          const distance = levenshteinDistance(normalizedExisting, normalizedNewAddress);
          const maxLength = Math.max(normalizedExisting.length, normalizedNewAddress.length);
          const similarity = 1 - (distance / maxLength);

          console.log(`Nearby property check:
            Address: ${prop.address}
            House number match: true
            Distance: ${distance}
            Similarity: ${similarity}
          `);

          return similarity >= 0.6; // More lenient threshold when house numbers match
        }

        // For properties without matching house numbers, require higher similarity
        const distance = levenshteinDistance(normalizedExisting, normalizedNewAddress);
        const maxLength = Math.max(normalizedExisting.length, normalizedNewAddress.length);
        const similarity = 1 - (distance / maxLength);

        console.log(`Nearby property check:
          Address: ${prop.address}
          House number match: false
          Distance: ${distance}
          Similarity: ${similarity}
        `);

        return similarity >= 0.9; // Stricter threshold when house numbers don't match
      });

      if (nearbyMatch) {
        console.log("Found matching nearby property:", nearbyMatch);
        return nearbyMatch.id;
      }
    }

    // No matching property found, create new one
    console.log("No matching property found. Creating new property with address:", addressDetails);

    // Get street view URL using the full address
    const streetViewUrl = getStreetViewImageUrl(addressDetails, process.env.GOOGLE_MAPS_API_KEY || '');

    // Final verification - one last exact match check before creation
    const [finalCheck] = await db
      .select()
      .from(properties)
      .where(
        and(
          sql`REGEXP_REPLACE(LOWER(${properties.address}), '[^a-z0-9]', '', 'g') = ${normalizedNewAddress}`,
          eq(properties.city, addressDetails.city),
          eq(properties.state, addressDetails.state),
          eq(properties.zipCode, addressDetails.zipCode)
        )
      )
      .limit(1);

    if (finalCheck) {
      console.log("Found matching property in final verification:", finalCheck);
      return finalCheck.id;
    }

    // Create new property
    const [newProperty] = await db
      .insert(properties)
      .values({
        address: addressDetails.address,
        city: addressDetails.city,
        state: addressDetails.state,
        zipCode: addressDetails.zipCode,
        latitude: gpsData.latitude,
        longitude: gpsData.longitude,
        status: "processing",
        streetViewUrl,
        isDeleted: false,
        createdAt: new Date(),
        updatedAt: new Date()
      })
      .returning();

    if (!newProperty) {
      throw new Error('Failed to create property');
    }

    console.log("Successfully created new property:", newProperty);
    return newProperty.id;

  } catch (error) {
    console.error("Error in findOrCreateProperty:", error);
    throw error;
  }
}

const inspectionSchema = z.object({
  propertyId: z.number(),
  photoId: z.number().optional(),
  status: z.enum(["draft", "completed"]).optional(),
  damageType: z.string(),
  severity: z.string(),
  notes: z.string().optional(),
  annotations: z.array(z.object({
    type: z.enum(["circle", "text", "sketch", "rectangle", "blur"]),
    x: z.number(),
    y: z.number(),
    radius: z.number().optional(),
    text: z.string().optional(),
    color: z.string(),
    points: z.array(z.number()).optional(),
    width: z.number().optional(),
    height: z.number().optional(),
    damageType: z.string(),
    severity: z.string()
  }))
});

interface FileChunk {
  chunkIndex: number;
  totalChunks: number;
  fileName: string;
  batchId: number;
}

// Memory-efficient chunk handling
async function handleFileChunks(chunkDir: string, fileName: string, totalChunks: number): Promise<string> {
  try {
    const chunks = await fs.readdir(chunkDir);
    const sortedChunks = chunks
      .filter(chunk => chunk.startsWith('chunk-'))
      .sort((a, b) => {
        const indexA = parseInt(a.split('-')[1]);
        const indexB = parseInt(b.split('-')[1]);
        return indexA - indexB;
      });

    if (sortedChunks.length !== totalChunks) {
      throw new Error(`Missing chunks for ${fileName}. Expected ${totalChunks}, got ${sortedChunks.length}`);
    }

    const finalPath = path.join(UPLOAD_DIR, fileName);
    const writeStream = require('fs').createWriteStream(finalPath);

    // Process chunks sequentially to manage memory
    for (const chunk of sortedChunks) {
      const chunkPath = path.join(chunkDir, chunk);
      await new Promise((resolve, reject) => {
        const readStream = require('fs').createReadStream(chunkPath);
        readStream.pipe(writeStream, { end: false });
        readStream.on('end', resolve);
        readStream.on('error', reject);
      });
      await fs.unlink(chunkPath); // Clean up chunk after use
    }

    writeStream.end();
    await new Promise((resolve) => writeStream.on('finish', resolve));
    await fs.rmdir(chunkDir).catch(console.error); // Clean up chunks directory
    return finalPath;
  } catch (error) {
    console.error('Error handling file chunks:', error);
    throw error;
  }
}


// Background processing function
async function processQueue() {
  if (isProcessing || PROCESSING_QUEUE.length === 0) return;

  isProcessing = true;
  while (PROCESSING_QUEUE.length > 0) {
    const { files, userId, batchId } = PROCESSING_QUEUE.shift()!;
    try {
      await processPhotoBatch(files, userId, batchId);
    } catch (error) {
      console.error('Error processing batch:', error);
    }
  }
  isProcessing = false;
}

// Update photo processing to be more robust
const processPhotoBatch = async (
  files: (Express.Multer.File & { id: number })[],
  userId: number,
  batchId: number
): Promise<{ success: number; errors: any[] }> => {
  const results = {
    success: 0,
    errors: [] as any[]
  };

  // Process files in smaller chunks to manage memory
  for (let i = 0; i < files.length; i += BATCH_SIZE) {
    const fileBatch = files.slice(i, i + BATCH_SIZE);
    console.log(`Processing batch ${Math.floor(i / BATCH_SIZE) + 1} of ${Math.ceil(files.length / BATCH_SIZE)}`);

    for (const file of fileBatch) {
      try {
        console.log(`Starting to process file: ${file.originalname}`);

        // Update status to processing
        await db
          .update(photos)
          .set({ processingStatus: 'processing' })
          .where(eq(photos.id, file.id));

        // Read the file to extract GPS data
        const buffer = await fs.readFile(file.path);
        const exifData = await ExifReader.load(buffer);
        const gpsData = extractGPSData(exifData);

        if (!gpsData || !gpsData.latitude || !gpsData.longitude) {
          throw new Error('No valid GPS data found in image');
        }

        // Find or create property based on GPS coordinates
        const propertyId = await findOrCreateProperty(gpsData, userId);
        console.log(`Property ID ${propertyId} assigned to photo ${file.id}`);

        // Update photo record with property ID and mark as processed
        await db
          .update(photos)
          .set({
            propertyId,
            processingStatus: 'processed'
          })
          .where(eq(photos.id, file.id));

        results.success++;
        console.log(`Successfully processed ${file.originalname}`);

      } catch (error) {
        console.error(`Error processing photo ${file.originalname}:`, error);
        // Update photo status to failed
        await db
          .update(photos)
          .set({ processingStatus: 'failed' })
          .where(eq(photos.id, file.id));

        results.errors.push({
          file: file.originalname,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }

    // Add a small delay between batches to prevent overwhelming the server
    await new Promise(resolve => setTimeout(resolve, 200));
  }

  return results;
};

interface FileUploadRequest extends Request {
  files: {
    report?: Express.Multer.File[];
    [key: string]: Express.Multer.File[] | undefined;
  };
}

interface UploadError {
  filename: string;
  error: string;
  originalName: string;
}

interface UploadResult {
  success: Photo[];
  noCoordinates: Photo[];
  errors: UploadError[];
}

export function registerRoutes(app: Express): any {
  // sets up /api/login, /api/logout, /api/user
  setupAuth(app);

  // Configure express for larger payloads
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Serve static files from uploads directory with proper MIME types and error handling
  app.use('/uploads', (req, res, next) => {
    const filePath = path.join(UPLOAD_DIR, req.path);

    // Verify file exists before serving
    fs.access(filePath)
      .then(() => {
        express.static(UPLOAD_DIR, {
          setHeaders: (res, filePath) => {
            // Set Cache-Control header
            res.setHeader('Cache-Control', 'public, max-age=31536000');

            // Set proper content type for images
            if (filePath.endsWith('.jpg') || filePath.endsWith('.jpeg')) {
              res.setHeader('Content-Type', 'image/jpeg');
            } else if (filePath.endsWith('.png')) {
              res.setHeader('Content-Type', 'image/png');
            } else if (filePath.endsWith('.tiff')) {
              res.setHeader('Content-Type', 'image/tiff');
            } else if (filePath.endsWith('.heic')) {
              res.setHeader('Content-Type', 'image/heic');
            }
          },
          fallthrough: false // Return 404 if file not found
        })(req, res, next);
      })
      .catch(() => {
        res.status(404).json({ error: "Image not found" });
      });
  });

  // Also serve the thumbnails directory
  app.use('/uploads/thumbnails', express.static(THUMBNAIL_DIR, {
    setHeaders: (res, filePath) => {
      res.setHeader('Cache-Control', 'public, max-age=31536000');
      if (filePath.endsWith('.jpg') || filePath.endsWith('.jpeg')) {
        res.setHeader('Content-Type', 'image/jpeg');
      } else if (filePath.endsWith('.png')) {
        res.setHeader('Content-Type', 'image/png');
      }
    }
  }));

  // Add routes for users
  app.get("/api/users", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const usersList = await db
        .select({
          id: users.id,
          username: users.username,
          role: users.role,
        })
        .from(users);

      res.json(usersList);
    } catch (error) {
      next(error);
    }
  });

  // Scan Batches endpoints
  app.post("/api/scan-batches", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          error: "Not authenticated",
          message: "You must be logged in to create a scan batch"
        });      }

      const { name, description, flightDate, userId } = req.body;

      if (!name || !flightDate) {
        return res.status(400).json({
          error: "Invalid input",
          message: "Name and flight date are required"
        });
      }

      // Update the batch user ID assignment to fix syntax error
      const batchUserId = (req.user?.role === 'admin' && userId) ? parseInt(userId) : req.user?.id;
      const [batch] = await db
        .insert(scan_batches)
        .values({
          name,          description,          flightDate: new Date(flightDate),
          userId: batchUserId,
        })
        .returning();

      res.json(batch);
    } catch (error) {
      next(error);
    }
  });

  app.get("/api/scan-batches", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          error: "Not authenticated",
          message: "You must be logged in to view scan batches"
        });
      }

      const batches = await db
        .select()
        .from(scan_batches)
        .where(eq(scan_batches.isDeleted, false))
        .orderBy(desc(scan_batches.createdAt));

      res.json(batches);
    } catch (error) {
      next(error);
    }
  });

  // Register property routes
  app.use(propertiesRouter);

  // Property routes
  app.get("/api/properties/:id", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const propertyId = parseInt(req.params.id);

      if (isNaN(propertyId)) {
        return res.status(400).json({
          error: "Invalid property ID",
          message: "Property ID must be a number"
        });
      }

      console.log("Fetching property details for ID:", propertyId);

      // Get property details with better error handling
      const [property] = await db
        .select()
        .from(properties)
        .where(
          and(
            eq(properties.id, propertyId),
            eq(properties.isDeleted, false)
          )
        )
        .limit(1);

      if (!property) {
        console.log("Property not found for ID:", propertyId);
        return res.status(404).json({
          error: "Property not found",
          message: `No property found with ID: ${propertyId}`
        });
      }

      console.log("Found property:", property);

      // Get property photos with proper joins and error handling
      const propertyPhotos = await db
        .select({
          photo: photos,
          user: {
            id: users.id,
            username: users.username,
            role: users.role
          },
          batch: {
            id: scan_batches.id,
            name: scan_batches.name,
            description: scan_batches.description,
            flightDate: scan_batches.flightDate
          }
        })
        .from(photos)
        .leftJoin(users, eq(photos.userId, users.id))
        .leftJoin(scan_batches, eq(photos.batchId, scan_batches.id))
        .where(eq(photos.propertyId, propertyId));

      // Format the response with proper error handling for each photo
      const formattedPhotos = propertyPhotos.map(({ photo, user, batch }) => ({
        ...photo,
        url: photo.filename ? `/uploads/${photo.filename}` : null,
        thumbnailUrl: photo.thumbnailPath ? `/uploads/thumbnails/${path.basename(photo.thumbnailPath)}` : null,
        altitude: photo.altitude ? formatAltitude(Number(photo.altitude), 'feet') : null,
        user: user || null,
        batch: batch || null
      })).filter(photo => photo.url !== null);

      const response = {
        ...property,
        photos: formattedPhotos,
        _meta: {
          photoCount: formattedPhotos.length,
          lastUpdated: new Date().toISOString()
        }
      };

      res.json(response);
    } catch (error) {
      console.error("Error fetching property details:", error);
      next(error);
    }
  });

  app.get("/api/properties", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const { status, search } = req.query;
      let query = db
        .select({
          property: properties,
          photoCount: sql<number>`COUNT(DISTINCT ${photos.id})`,
          inspectionCount: sql<number>`COUNT(DISTINCT ${inspections.id})`
        })
        .from(properties)
        .leftJoin(photos, and(
          eq(photos.propertyId, properties.id),
          eq(photos.isDeleted, false)
        ))
        .leftJoin(inspections, and(
          eq(inspections.propertyId, properties.id)
        ))
        .where(eq(properties.isDeleted, false))
        .groupBy(properties.id);

      if (status && status !== 'all') {
        query = query.where(eq(properties.status, status as string));
      }

      if (search) {
        const searchTerm = `%${search}%`;
        query = query.where(
          or(
            sql`${properties.address} ILIKE ${searchTerm}`,
            sql`${properties.city} ILIKE ${searchTerm}`,
            sql`${properties.state} ILIKE ${searchTerm}`
          )
        );
      }

      const results = await query;

      const formattedProperties = results.map(({ property, photoCount, inspectionCount }) => ({
        ...property,
        photoCount: Number(photoCount),
        inspectionCount: Number(inspectionCount)
      }));

      res.json({ properties: formattedProperties });
    } catch (error) {
      console.error('Error fetching properties:', error);
      next(error);
    }
  });
  // Photo upload endpoints
  app.post("/api/photos/upload-chunk", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const chunkUpload = multer({
        storage: storage,
        limits: { fileSize: MAX_CHUNK_SIZE }
      }).single('chunk');
      chunkUpload(req, res, async (err) => {
        if (err) {
          return res.status(400).json({ error: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ error: "No chunk uploaded" });
        }
        const { chunkIndex, totalChunks, fileName, batchId } = req.body;
        // Validate chunk information
        if (!chunkIndex || !totalChunks || !fileName || !batchId) {
          return res.status(400).json({ error: "Missing chunk information" });
        }
        const currentChunk = parseInt(chunkIndex);
        const totalChunksNum = parseInt(totalChunks);
        // If this was the last chunk, process the complete file
        if (currentChunk === totalChunksNum - 1) {
          try {
            const chunkDir = path.join(CHUNK_DIR, path.basename(fileName, path.extname(fileName)));
            const finalPath = await handleFileChunks(chunkDir, fileName, totalChunksNum);
            // Process the completed file
            const buffer = await fs.readFile(finalPath);
            const tags = await ExifReader.load(buffer);
            const gpsData = extractGPSData(tags);
            if (!gpsData || !gpsData.latitude || !gpsData.longitude) {
              await fs.unlink(finalPath);
              return res.status(400).json({
                error: "No valid GPS data",
                message: "The image does not contain valid GPS coordinates"
              });
            }
            // Find or create property based on GPS coordinates
            const propertyId = await findOrCreateProperty(gpsData, req.user.id);
            // Save to database with proper metadata
            const metadata: ExifMetadata = {
              gps: gpsData,
              DateTimeOriginal: parseTimestamp(tags)
            };
            const [photo] = await db
              .insert(photos)
              .values({
                propertyId,
                userId: req.user.id,
                batchId: parseInt(batchId),
                filename: path.basename(finalPath),
                originalName: fileName,
                mimeType: req.file.mimetype,
                size: (await fs.stat(finalPath)).size,
                latitude: gpsData.latitude,
                longitude: gpsData.longitude,
                altitude: gpsData.altitude,
                takenAt: metadata.DateTimeOriginal ? new Date(metadata.DateTimeOriginal) : null,
                metadata: metadata,
                storageLocation: finalPath,
                processingStatus: "processed"
              })
              .returning();
            res.json({
              message: "File upload complete",
              photo,
              propertyId
            });
          } catch (error) {
            console.error("Error processing completed file:", error);
            res.status(500).json({
              error: "Failed to process completed file",
              message: error instanceof Error ? error.message : String(error)
            });
          }
        } else {
          // Not the last chunk, acknowledge receipt
          res.json({
            message: "Chunk received",
            currentChunk,
            remainingChunks: totalChunksNum - currentChunk - 1
          });
        }
      });
    } catch (error) {
      next(error);
    }
  });
  // Regular upload endpoint for smaller files
  app.post("/api/photos/upload", imageUpload.array("photos", 100), async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      if (!req.files || !Array.isArray(req.files)) {
        return res.status(400).json({ error: "No files uploaded" });
      }

      const batchId = parseInt(req.body.batchId);
      if (isNaN(batchId)) {
        return res.status(400).json({ error: "Invalid batch ID" });
      }

      const result: UploadResult = {
        success: [],
        noCoordinates: [],
        errors: []
      };

      for (const file of req.files as Express.Multer.File[]) {
        try {
          console.log(`Processing file: ${file.originalname}`);
          const buffer = await fs.readFile(file.path);
          const metadata: ExifMetadata = { gps: undefined, DateTimeOriginal: null };

          try {
            const tags = await ExifReader.load(buffer);
            const gpsData = extractGPSData(tags);
            if (gpsData) {
              metadata.gps = gpsData;
            }
            metadata.DateTimeOriginal = parseTimestamp(tags);
          } catch (exifError) {
            console.error('Error reading EXIF data:', exifError);
          }

          // Generate thumbnail
          const thumbnailFileName = `thumb_${file.filename}`;
          const thumbnailPath = path.join(THUMBNAIL_DIR, thumbnailFileName);

          try {
            await imageProcessor.createThumbnail(file.path, thumbnailPath);
          } catch (thumbError) {
            console.error('Error creating thumbnail:', thumbError);
          }

          // Save to database with coordinates if available
          const photo = await savePhotoToDatabase(
            file,
            metadata.gps ? 0 : null, // propertyId is null if no coordinates
            req.user.id,
            metadata,
            batchId,
            thumbnailPath
          );

          if (metadata.gps) {
            result.success.push(photo);
          } else {
            result.noCoordinates.push(photo);
          }

        } catch (error) {
          console.error(`Error processing ${file.originalname}:`, error);
          result.errors.push({
            filename: file.filename,
            originalName: file.originalname,
            error: error instanceof Error ? error.message : 'Unknown error'
          });

          // Clean up failed file
          await fs.unlink(file.path).catch(console.error);
        }
      }

      // Add the failed and no-coordinates photos to the processing queue for later handling
      if (result.noCoordinates.length > 0) {
        PROCESSING_QUEUE.push({
          files: result.noCoordinates,
          userId: req.user.id,
          batchId,
          type: 'no-coordinates'
        });
      }

      res.json({
        message: 'Upload complete',
        totalUploaded: req.files.length,
        successful: result.success.length,
        noCoordinates: result.noCoordinates.length,
        failed: result.errors.length,
        details: result
      });

    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({
        error: 'Upload failed',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Add endpoint to get upload status and errors
  app.get("/api/photos/upload-status", async (req: AuthenticatedRequest, res: Response) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const batchId = parseInt(req.query.batchId as string);
      if (isNaN(batchId)) {
        return res.status(400).json({ error: "Invalid batch ID" });
      }

      const photos = await db
        .select({
          photo: photos,
          propertyId: photos.propertyId,
          processingStatus: photos.processingStatus,
          error: sql<string>`CASE 
            WHEN photos.processing_status = 'failed' 
            THEN photos.metadata->>'error' 
            ELSE NULL 
          END`
        })
        .from(photos)
        .where(
          and(
            eq(photos.batchId, batchId),
            eq(photos.isDeleted, false)
          )
        );

      const result = {
        total: photos.length,
        processed: photos.filter(p => p.photo.processingStatus === 'processed').length,
        failed: photos.filter(p => p.photo.processingStatus === 'failed').length,
        pending: photos.filter(p => p.photo.processingStatus === 'pending').length,
        noCoordinates: photos.filter(p => !p.propertyId).length,
        photos: photos.map(p => ({
          ...p.photo,
          error: p.error,
          url: p.photo.filename ? `/uploads/${p.photo.filename}` : null,
          thumbnailUrl: p.photo.thumbnailPath ? `/uploads/thumbnails/${path.basename(p.photo.thumbnailPath)}` : null
        }))
      };

      res.json(result);

    } catch (error) {
      console.error('Error getting upload status:', error);
      res.status(500).json({
        error: 'Failed to get upload status',
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Update the processing status endpoint
  app.get("/api/photos/processing-status", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const batchId = parseInt(req.query.batchId as string);
      if (!batchId) {
        return res.status(400).json({ error: "Batch ID is required" });
      }
      // Get detailed status counts with processing errors
      const [result] = await db
        .select({
          total: sql<number>`count(*)`,
          processed: sql<number>`count(*) filter (where processing_status = 'processed')`,
          failed: sql<number>`count(*) filter (where processing_status = 'failed')`,
          pending: sql<number>`count(*) filter (where processing_status = 'pending')`,
          withProperty: sql<number>`count(*) filter (where property_id is not null)`
        })
        .from(photos)
        .where(eq(photos.batchId, batchId));
      // Calculate actual progress
      const progress = (result.processed + result.failed) / result.total;
      // Check if any photos are still pending
      const isComplete = result.pending === 0;
      // Check if all processed photos have properties
      const allPropertiesCreated = result.withProperty === result.processed;
      const status = result.failed > 0 ? 'error' :
        (isComplete && allPropertiesCreated) ? 'completed' :
          'processing';
      return res.json({
        status,
        progress,
        details: {
          total: result.total,
          processed: result.processed,
          failed: result.failed,
          pending: result.pending,
          withProperty: result.withProperty
        }
      });
    } catch (error) {
      next(error);
    }
  });
  app.get("/api/photos/:id", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const photoId = parseInt(req.params.id);
      if (isNaN(photoId)) {
        return res.status(400).json({ error: "Invalid photo ID" });
      }
      const [photo] = await db
        .select()
        .from(photos)
        .where(eq(photos.id, photoId))
        .limit(1);
      if (!photo) {
        return res.status(404).json({ error: "Photo not found" });
      }
      // Get user's preferred altitude unit
      const [preferences] = await db
        .select()
        .from(user_preferences)
        .where(eq(user_preferences.userId, req.user.id))
        .limit(1);
      const altitudeUnit = preferences?.altitudeUnit || 'feet';
      // Format response
      const response = {
        ...photo,
        url: `/uploads/${photo.filename}`,
        thumbnailUrl: photo.thumbnailPath ? `/uploads/${photo.thumbnailPath}` : `/uploads/${photo.filename}`,
        altitude: photo.altitude ? formatAltitude(Number(photo.altitude), altitudeUnit) : null,
      };
      res.json(response);
    } catch (error) {
      next(error);
    }
  });
  app.get("/api/stats", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      // Get total properties
      const [{ count: totalProperties }] = await db
        .select({
          count: sql<number>`cast(count(*) as integer)`
        })
        .from(properties)
        .where(eq(properties.isDeleted, false));
      // Get total photos
      const [{ count: totalPhotos }] = await db
        .select({
          count: sql<number>`cast(count(*) as integer)`
        })
        .from(photos)
        .where(eq(photos.isDeleted, false));
      // Get total inspections - removed isDeleted check since it doesn't exist
      const [{ count: totalInspections }] = await db
        .select({
          count: sql<number>`cast(count(*) as integer)`
        })
        .from(inspections);
      // Calculate average photos per property
      const avgPhotosPerProperty = totalProperties > 0
        ? Number((totalPhotos / totalProperties).toFixed(2))
        : 0;
      // Get properties by status
      const propertiesByStatus = await db
        .select({
          status: properties.status,
          count: sql<number>`cast(count(*) as integer)`
        })
        .from(properties)
        .where(eq(properties.isDeleted, false))
        .groupBy(properties.status);
      // Get recent activity (recently updated properties)
      const recentActivity = await db
        .select()
        .from(properties)
        .where(eq(properties.isDeleted, false))
        .orderBy(desc(properties.updatedAt))
        .limit(5);
      res.json({
        totalProperties,
        totalPhotos,
        totalInspections,
        avgPhotosPerProperty,
        propertiesByStatus,
        recentActivity,
      });
    } catch (error) {
      next(error);
    }
  });
  // Places API autocomplete endpoint
  app.get("/api/places/autocomplete", async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { input } = req.query;
      if (!process.env.GOOGLE_MAPS_API_KEY) {
        throw new Error("Google Maps API key not configured");
      }
      if (!input || typeof input !== 'string') {
        return res.status(400).json({
          error: "Missing input",
          message: "Search input is required"
        });
      }
      const response = await googleMapsClient.placeAutocomplete({
        params: {
          input: input,
          key: process.env.GOOGLE_MAPS_API_KEY,
          types: ["address", "geocode"],
          components: [{ type: "country", value: "us" }]
        },
      });
      if (response.data.error_message) {
        console.error('Places API Error:', response.data.error_message);
        throw new Error(`Places API Error: ${response.data.error_message}`);
      }
      res.json({
        predictions: response.data.predictions
      });
    } catch (error: any) {
      console.error('Places API Error:', error);
      res.status(error.status || 400).json({
        error: "Failed to fetch suggestions",
        details: error.message
      });
    }
  });
  // Geocoding endpoint
  app.get("/api/geocode", async (req: Request, res: Response) => {
    try {
      const { placeId } = req.query;
      if (!process.env.GOOGLE_MAPS_API_KEY) {
        throw new Error("Google Maps API key not configured");
      }
      if (!placeId) {
        return res.status(400).json({
          error: "Missing placeId",
          message: "Place ID is required"
        });
      }
      const response = await googleMapsClient.placeDetails({
        params: {
          place_id: placeId as string,
          key: process.env.GOOGLE_MAPS_API_KEY,
          fields: ["geometry"]
        },
      });
      if (response.data.status !== "OK" || !response.data.result?.geometry?.location) {
        throw new Error("Failed to get location details");
      }
      res.json({
        location: response.data.result.geometry.location
      });
    } catch (error: any) {
      console.error('Geocoding error:', error);
      res.status(400).json({
        error: "Geocoding failed",
        message: error.message
      });
    }
  });
  // Update the historical weather endpoint
  app.get("/api/weather/historical", async (req: Request, res: Response) => {
    try {
      const { lat, lng, startDate, endDate } = req.query;
      if (!lat || !lng || !startDate || !endDate) {
        return res.status(400).json({
          error: "Missing parameters",
          message: "Latitude, longitude, start date and end date are required"
        });
      }
      res.json({
        message: "Historical weather endpoint implementation pending"
      });
    } catch (error) {
      console.error('Historical weather error:', error);
      res.status(500).json({
        error: "Failed to fetch historical weather data",
        message: error instanceof Error ? error.message : String(error)
      });
    }
  });
  // Add inspection routes
  app.post("/api/properties/:propertyId/inspections", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          error: "Not authenticated",
          message: "You must be logged in to create inspections"
        });
      }
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({
          error: "Invalid property ID",
          message: "Property ID must be a number"
        });
      }
      // Validate the request body
      const validatedData = inspectionSchema.parse(req.body);
      // Create the inspection
      const [inspection] = await db
        .insert(inspections)
        .values({
          propertyId: propertyId,
          userId: req.user.id,
          photoId: validatedData.photoId,
          status: validatedData.status || "draft",
          damageType: validatedData.damageType,
          severity: validatedData.severity,
          notes: validatedData.notes,
          annotations: validatedData.annotations,
          createdAt: new Date(),
          completedAt: validatedData.status === "completed" ? new Date() : null,
          aiAnalysisStatus: "pending"
        })
        .returning();
      if (!inspection) {
        throw new Error("Failed to create inspection");
      }
      // Update property's last inspection date
      await db
        .update(properties)
        .set({
          lastInspectionAt: new Date(),
          updatedAt: new Date()
        })
        .where(eq(properties.id, propertyId));
      // Format the response
      const response = {
        ...inspection,
        createdAt: inspection.createdAt?.toISOString(),
        completedAt: inspection.completedAt?.toISOString(),
        annotations: inspection.annotations || [],
        aiFindings: inspection.aiFindings || null,
      };
      res.status(201).json(response);
    } catch (error) {
      console.error("Error creating inspection:", error);
      next(error);
    }
  });
  // GET inspections for a property
  app.get("/api/properties/:propertyId/inspections", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({
          error: "Not authenticated",
          message: "You must be logged in to view inspections"
        });
      }
      const propertyId = parseInt(req.params.propertyId);
      if (isNaN(propertyId)) {
        return res.status(400).json({
          error: "Invalid property ID",
          message: "Property ID must be a number"
        });
      }
      // Get all inspections for the property
      const propertyInspections = await db
        .select()
        .from(inspections)
        .where(eq(inspections.propertyId, propertyId))
        .orderBy(desc(inspections.createdAt));
      // Format the response
      const formattedInspections = propertyInspections.map(inspection => ({
        id: inspection.id,
        propertyId: inspection.propertyId,
        userId: inspection.userId,
        photoId: inspection.photoId,
        status: inspection.status,
        damageType: inspection.damageType,
        severity: inspection.severity,
        notes: inspection.notes,
        annotations: inspection.annotations || [],
        createdAt: inspection.createdAt.toISOString(),
        completedAt: inspection.completedAt?.toISOString(),
        aiFindings: inspection.aiFindings
      }));
      res.json(formattedInspections);
    } catch (error) {
      next(error);
    }
  });
  // Update batch inspection endpoint to handle annotations properly
  app.post("/api/properties/:propertyId/inspection/batch", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const propertyId = parseInt(req.params.propertyId);
      const { status, notes, photos } = req.body;
      console.log('Received inspection data:', {
        propertyId,
        userId: req.user.id,
        status,
        photoCount: photos.length,
        notes,
        photos // Log the full photos data
      });
      // Format the annotations structure
      const photoAnnotations = photos.map(photo => ({
        photoId: photo.photo_id,
        annotations: photo.annotations || [],
        notes: photo.notes || "",
        damageType: photo.damage_type || "other",
        severity: photo.severity || "low"
      }));
      // Create a single inspection for all photos
      const [inspection] = await db
        .insert(inspections)
        .values({
          propertyId,
          userId: req.user.id,
          status: status || "draft",
          notes: notes || "",
          damageType: photos[0]?.damage_type || "other",
          severity: photos[0]?.severity || "low",
          createdAt: new Date(),
          completedAt: status === "completed" ? new Date() : null,
          annotations: photoAnnotations // Store annotations for all photos
        })
        .returning();
      console.log('Created inspection:', inspection);
      res.json({
        message: "Inspection saved successfully",
        propertyId,
        inspectionId: inspection.id,
        photosProcessed: photos.length
      });
    } catch (error) {
      console.error('Error creating batch inspection:', error);
      next(error);
    }
  });
  // Update GET inspection endpoint for proper photo annotations
  app.get("/api/properties/:propertyId/inspection/:inspectionId", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const propertyId = parseInt(req.params.propertyId);
      const inspectionId = parseInt(req.params.inspectionId);
      console.log('Fetching inspection:', { inspectionId, propertyId });
      // Get inspection details
      const [inspection] = await db
        .select()
        .from(inspections)
        .where(
          and(
            eq(inspections.id, inspectionId),
            eq(inspections.propertyId, propertyId)
          )
        )
        .limit(1);
      if (!inspection) {
        return res.status(404).json({ error: "Inspection not found" });
      }
      // Get photos associated with this inspection
      const inspectionPhotos = await db
        .select()
        .from(photos)
        .where(eq(photos.propertyId, propertyId));
      // Ensure annotations is an array
      const photoAnnotations = Array.isArray(inspection.annotations)
        ? inspection.annotations
        : [];
      // Format the response
      const response = {
        id: inspection.id,
        propertyId: inspection.propertyId,
        status: inspection.status,
        damageType: inspection.damageType,
        severity: inspection.severity,
        notes: inspection.notes || "",
        createdAt: inspection.createdAt?.toISOString(),
        completedAt: inspection.completedAt?.toISOString(),
        photos: inspectionPhotos.map(photo => {
          // Find the annotations for this photo
          const photoAnnotation = photoAnnotations.find(a => a.photoId === photo.id);
          return {
            id: photo.id,
            filename: photo.filename,
            originalName: photo.originalName,
            url: `/uploads/${photo.filename}`,
            annotations: photoAnnotation?.annotations || [],
            notes: photoAnnotation?.notes || "",
            damageType: photoAnnotation?.damageType || inspection.damageType,
            severity: photoAnnotation?.severity || inspection.severity
          };
        })
      };
      console.log('Sending inspection response:', response);
      res.json(response);
    } catch (error) {
      console.error('Error retrieving inspection:', error);
      next(error);
    }
  });
  // Update inspection endpoint
  app.put("/api/properties/:propertyId/inspection/:inspectionId", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const inspectionId = parseInt(req.params.inspectionId);
      const propertyId = parseInt(req.params.propertyId);
      const { photoId, annotations, notes, damageType, severity, status } = req.body;
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      console.log('Updating inspection:', {
        inspectionId,
        propertyId,
        photoId,
        annotations,
        notes,
        damageType,
        severity,
        status
      });
      // Get current inspection
      const [currentInspection] = await db
        .select()
        .from(inspections)
        .where(eq(inspections.id, inspectionId))
        .limit(1);
      if (!currentInspection) {
        return res.status(404).json({ error: "Inspection not found" });
      }
      // Update annotations for the specific photo
      let updatedAnnotations = currentInspection.annotations || [];
      if (photoId) {
        const photoIndex = updatedAnnotations.findIndex(a => a.photoId === photoId);
        const photoAnnotation = {
          photoId,
          annotations: annotations || [],
          notes: notes || "",
          damageType: damageType || "none",
          severity: severity || "low"
        };
        if (photoIndex >= 0) {
          updatedAnnotations[photoIndex] = photoAnnotation;
        } else {
          updatedAnnotations.push(photoAnnotation);
        }
      }
      // Update the inspection record with all its fields
      const [updatedInspection] = await db
        .update(inspections)
        .set({
          annotations: updatedAnnotations,
          status: status || currentInspection.status,
          damageType: damageType || currentInspection.damageType,
          severity: severity || currentInspection.severity,
          notes: notes || currentInspection.notes,
          updatedAt: new Date(),
          completedAt: status === "completed" ? new Date() : currentInspection.completedAt
        })
        .where(eq(inspections.id, inspectionId))
        .returning();
      // Return full inspection details
      const photos = await db
        .select()
        .from(photos)
        .where(eq(photos.propertyId, propertyId));
      const formattedPhotos = photos.map(photo => {
        const photoAnnotation = updatedAnnotations.find(a => a.photoId === photo.id);
        return {
          id: photo.id,
          filename: photo.filename,
          originalName: photo.originalName,
          url: `/uploads/${photo.filename}`,
          annotations: photoAnnotation?.annotations || [],
          notes: photoAnnotation?.notes || "",
          damageType: photoAnnotation?.damageType || "none",
          severity: photoAnnotation?.severity || "low"
        };
      });
      res.json({
        ...updatedInspection,
        photos: formattedPhotos
      });
    } catch (error) {
      next(error);
    }
  });
  app.delete("/api/properties/:propertyId/inspection/:inspectionId", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const inspectionId = parseInt(req.params.inspectionId);
      const propertyId = parseInt(req.params.propertyId);
      console.log('Deleting inspection:', { inspectionId, propertyId });
      await db
        .delete(inspections)
        .where(
          and(
            eq(inspections.id, inspectionId),
            eq(inspections.propertyId, propertyId)
          )
        );
      res.json({ message: "Inspection deleted successfully" });
    } catch (error) {
      console.error('Error deleting inspection:', error);
      next(error);
    }
  });
  // Add inspection completion endpoint with proper error handling
  app.post("/api/inspections/:id/complete", async (req: AuthenticatedRequest, res: Response) => {
    try {
      const inspectionId = parseInt(req.params.id);
      console.log('Completing inspection:', inspectionId);

      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      if (isNaN(inspectionId)) {
        return res.status(400).json({
          error: "Invalid inspection ID",
          message: "Inspection ID must be a number"
        });
      }

      const { photos, overallNotes } = req.body;

      if (!Array.isArray(photos)) {
        return res.status(400).json({
          error: "Invalid request",
          message: "Photos must be an array"
        });
      }

      // Update inspection status and notes
      const [inspection] =await db
        .update(inspections)
        .set({
          status: 'completed',
          completedAt: new Date(),
          notes: overallNotes
        })
        .where(eq(inspections.id, inspectionId))
        .returning();

      if (!inspection) {
        return res.status(404).json({
          error: "Not found",
          message: "Inspection not found"
        });
      }

      // Update photos with annotations and analysis
      for (const photo of photos) {
        await db
          .update(photos)
          .set({
            editedImage: photo.capturedImage,
            analysis: photo.analysis,
            isDefault: photo.isDefault || false
          })
          .where(eq(photos.id, photo.photoId));
      }

      console.log('Successfully completed inspection:', inspectionId);

      res.json({
        message:"Inspection completed successfully",
        inspection
      });

    } catch (error) {
      console.error("Error completing inspection:", error);
      res.status(500).json({
        error: "Internal Server Error",
        message: error instanceof Error ? error.message : "Failed to complete inspection"
      });
    }
  });

  // Update the inspection download endpoint
  app.get("/api/inspections/:id/download", async (req: AuthenticatedRequest, res: Response) => {
    try {
      const inspectionId = parseInt(req.params.id);
      console.log('Generating PDF for inspection:', inspectionId);

      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      if (isNaN(inspectionId)) {
        return res.status(400).json({
          error: "Invalid inspection ID",
          message: "Inspection ID must be a number"
        });
      }

      // Get inspection with all related data
      const inspection = await db.query.inspections.findFirst({
        where: eq(inspections.id, inspectionId),
        with: {
          property: true,
          photos: {
            where: eq(photos.isDeleted, false)
          }
        }
      });

      if (!inspection || !inspection.property) {
        return res.status(404).json({
          error: "Not found",
          message: "Inspection or property not found"
        });
      }

      // Format data for PDF generation
      const reportData = {
        property: {
          address: inspection.property.address,
          city: inspection.property.city,
          state: inspection.property.state,
          zipCode: inspection.property.zipCode,
          parcelNumber: inspection.property.parcelNumber,
          yearBuilt: inspection.property.yearBuilt,
          propertyUse: inspection.property.propertyUse,
          propertyValue: inspection.property.propertyValue,
          landValue: inspection.property.landValue,
          improvementValue: inspection.property.improvementValue
        },
        owners: {
          primary: inspection.property.owner1FirstName || inspection.property.owner1LastName ? {
            name: `${inspection.property.owner1FirstName || ''} ${inspection.property.owner1LastName || ''}`.trim(),
            company: inspection.property.owner1Company,
            phone: inspection.property.owner1Phone,
            email: inspection.property.owner1Email
          } : undefined,
          secondary: inspection.property.owner2FirstName || inspection.property.owner2LastName ? {
            name: `${inspection.property.owner2FirstName || ''} ${inspection.property.owner2LastName || ''}`.trim(),
            company: inspection.property.owner2Company,
            phone: inspection.property.owner2Phone,
            email: inspection.property.owner2Email
          } : undefined
        },
        inspectionData: inspection.photos.map(photo => ({
          photoId: photo.id,
          editedImage: photo.editedImage || `/uploads/${photo.filename}`,
          damageType: inspection.damageType || 'unknown',
          severity: inspection.severity || 'unknown',
          notes: inspection.notes || '',
          weather: photo.metadata?.weather || null
        }))
      };

      // Generate PDF
      const pdfData = await generateInspectionReport(reportData);
      const pdfBuffer = Buffer.from(pdfData.split(',')[1], 'base64');

      // Set response headers for PDF download
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="inspection-${inspectionId}.pdf"`);

      // Send the PDF
      res.send(pdfBuffer);

    } catch (error) {
      console.error('Error generating PDF:', error);
      res.status(500).json({
        error: "Internal Server Error",
        message: "Failed to generate PDF report"
      });
    }
  });

  // Add report upload endpoint with PDF-specific upload middleware
  app.post(
    "/api/properties/:id/inspections/:inspectionId/report",
    pdfUpload.single('report'),
    async (req: AuthenticatedRequest & { file?: Express.Multer.File }, res: Response) => {
      try {
        if (!req.user) {
          return res.status(401).json({
            error: "Unauthorized",
            message: "Authentication required"
          });
        }

        const propertyId = parseInt(req.params.id);
        const inspectionId = parseInt(req.params.inspectionId);

        if (isNaN(propertyId) || isNaN(inspectionId)) {
          return res.status(400).json({ error: "Invalid property or inspection ID" });
        }

        const inspection = await db.query.inspections.findFirst({
          where: and(
            eq(inspections.id, inspectionId),
            eq(inspections.propertyId, propertyId)
          )
        });

        if (!inspection) {
          return res.status(404).json({ error: "Inspection not found" });
        }

        // Handle file upload

        if (!req.file) {
          return res.status(400).json({ error: "No report file provided" });
        }

        try {
          console.log('Creating report record...');
          const [report] = await db
            .insert(reports)
            .values({
              inspectionId,
              propertyId,
              reportPath: req.file.path,
              status: 'completed',
              reportType: 'inspection',
              createdAt: new Date(),
              metadata: {
                originalName: req.file.originalname,
                mimeType: req.file.mimetype,
                size: req.file.size
              }
            })
            .returning();

          console.log('Report created:', report);

          // Update inspection status
          await db
            .update(inspections)
            .set({
              status: 'completed',
              completedAt: new Date()
            })
            .where(eq(inspections.id, inspectionId));

          res.json({
            success: true,
            report: {
              id: report.id,
              path: `/uploads/reports/${path.basename(req.file.path)}`,
              createdAt: report.createdAt
            }
          });
        } catch (dbError) {
          console.error('Database error:', dbError);
          res.status(500).json({ error: "Failed to save report to database" });
        }
      } catch (error) {
        console.error('Report upload error:', error);
        res.status(500).json({ error: "Internal server error" });
      }
    }
  );

  // Add endpoint to serve PDF reports
  app.get('/uploads/reports/:filename', (req, res, next) => {
    const filename = req.params.filename;
    const reportPath = path.join(UPLOAD_DIR, 'reports', filename);

    // Verify file exists before serving
    fs.access(reportPath)
      .then(() => {
        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', `inline; filename="${filename}"`);
        res.sendFile(reportPath);
      })
      .catch(() => {
        res.status(404).json({ error: "Report not found" });
      });
  });

  // Error handling middleware
  app.use((err: any, req: Request, res: Response, next: NextFunction) => {
    console.error('Error:', err);
    res.status(err.status || 500).json({
      error: err.message || 'Internal server error',
      details: process.env.NODE_ENV === 'development' ? err.stack : undefined
    });
  });
  // Create server
  const httpServer = createServer(app);
  // Add endpoint to set default photo
  app.post("/api/photos/:id/set-default", async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      const photoId = parseInt(req.params.id);
      const propertyId = parseInt(req.query.propertyId as string);
      if (isNaN(photoId) || isNaN(propertyId)) {
        return res.status(400).json({
          error: "Invalid request",
          message: "Photo ID and property ID are required"
        });
      }
      // Reset any existing default photos for this property
      await db
        .update(photos)
        .set({ isDefault: false })
        .where(eq(photos.propertyId, propertyId));
      // Set the new default photo
      const [updatedPhoto] = await db
        .update(photos)
        .set({ isDefault: true })
        .where(eq(photos.id, photoId))
        .returning();
      if (!updatedPhoto) {
        return res.status(404).json({
          error: "Photo not found",
          message: `No photo found with ID: ${photoId}`
        });
      }
      res.json(updatedPhoto);
    } catch (error) {
      next(error);
    }
  });
  // Add proper error handling middleware and JSON response handling
  app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
    console.error('Global error handler:', err);
    res.status(500).json({
      error: 'Internal Server Error',
      message: err.message
    });
  });

  // Add these routes after the existing inspection routes

  // Generate and download inspection PDF
  app.get("/api/inspections/:id/download", async (req: AuthenticatedRequest, res: Response) => {
    try {
      const inspectionId = parseInt(req.params.id);

      if (isNaN(inspectionId)) {
        return res.status(400).json({
          error: "Invalid inspection ID",
          message: "Inspection ID must be a number"
        });
      }

      // Get inspection details with associated property and photos
      const inspection = await db.query.inspections.findFirst({
        where: eq(inspections.id, inspectionId),
        with: {
          property: true,
          photos: {
            where: eq(photos.isDeleted, false)
          }
        }
      });

      if (!inspection) {
        return res.status(404).json({
          error: "Not found",
          message: "Inspection not found"
        });
      }

      // Format data for PDF generation
      const reportData = {
        property: {
          address: inspection.property.address,
          city: inspection.property.city,
          state: inspection.property.state,
          zipCode: inspection.property.zipCode,
          parcelNumber: inspection.property.parcelNumber,
          yearBuilt: inspection.property.yearBuilt,
          propertyUse: inspection.property.propertyUse,
          propertyValue: inspection.property.propertyValue,
          landValue: inspection.property.landValue,
          improvementValue: inspection.property.improvementValue
        },
        owners: {
          primary: inspection.property.owner1FirstName || inspection.property.owner1LastName ? {
            name: `${inspection.property.owner1FirstName || ''} ${inspection.property.owner1LastName || ''}`.trim(),
            company: inspection.property.owner1Company,
            phone: inspection.property.owner1Phone,
            email: inspection.property.owner1Email
          } : undefined,
          secondary: inspection.property.owner2FirstName || inspection.property.owner2LastName ? {
            name: `${inspection.property.owner2FirstName || ''} ${inspection.property.owner2LastName || ''}`.trim(),
            company: inspection.property.owner2Company,
            phone: inspection.property.owner2Phone,
            email: inspection.property.owner2Email
          } : undefined
        },
        inspectionData: inspection.photos.map(photo => ({
          photoId: photo.id,
          editedImage: photo.filename ? `/uploads/${photo.filename}` : '',
          damageType: inspection.damageType || 'unknown',
          severity: inspection.severity || 'unknown',
          notes: inspection.notes || '',
          weather: photo.metadata?.weather
        }))
      };

      // Generate PDF and send it
      const pdfData = await generateInspectionReport(reportData);
      const pdfBuffer = Buffer.from(pdfData.split(',')[1], 'base64');

      // Set response headers for PDF download
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="inspection-${inspectionId}.pdf"`);

      // Send the PDF
      res.send(pdfBuffer);
    } catch (error) {
      console.error('Error generating PDF:', error);
      res.status(500).json({
        error: "Internal Server Error",
        message: "Failed to generate PDF report"
      });
    }
  });

  return httpServer;
}

// Placeholder for PDF generation function.  Requires a library like PDFKit or jsPDF.
async function generateInspectionReport(reportData: any): Promise<string> {
  //This is a placeholder. Replace with actual PDF generation logic using a library like PDFKit or jsPDF.
  return "data:application/pdf;base64,SGVsbG8gV29ybGQh"; // Returns a dummy PDF
}