import { eq, and } from "drizzle-orm";
import { db } from "@db";
import { photos, properties } from "@db/schema";
import type { Property, Photo } from "@db/schema";
import { Client } from "@googlemaps/google-maps-services-js";
import { z } from "zod";
import * as turf from "@turf/turf";

interface MatchResult {
  propertyId: string | null;
  address: string | null;
  ownerName?: string;
  ownerCareOf?: string;
  parcelNumber?: string;
  yearBuilt?: number;
  propertyValue?: number;
  improvementValue?: number;
  landValue?: number;
  use?: string;
  zoning?: string;
  confidence: number;
  matchMethod: string;
}

interface CachedProperty {
  timestamp: number;
  data: RegridProperty;
}

const propertyCache = new Map<string, CachedProperty>();
const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 hours

export class PhotoMatcher {
  private readonly MAX_DISTANCE_METERS = 15; // Reduced for higher accuracy
  private readonly MIN_TOTAL_CONFIDENCE = 0.99; // Increased to match DB constraint

  constructor(private regridApiKey: string) {
    if (!regridApiKey) {
      throw new Error("REGRID_API_KEY is required");
    }
  }

  async findMatchingProperty(
    photo: Photo,
    batchPhotos: Photo[] = []
  ): Promise<MatchResult> {
    try {
      // Step 1: Validate photo coordinates
      const { latitude, longitude } = photo;
      if (!latitude || !longitude) {
        return { propertyId: null, address: null, confidence: 0, matchMethod: 'no_coordinates' };
      }

      // Step 2: Check cached property data
      const cacheKey = `${latitude},${longitude}`;
      let property = this.getCachedProperty(cacheKey);

      // Step 3: If not cached, decide search radius based on area density
      const radius = await this.isHighDensityArea(latitude, longitude) ? 20 : 50;  // meters
      if (!property) {
        property = await this.queryRegridProperty(latitude, longitude, radius);
        if (property) {
          this.cachePropertyProfile(cacheKey, property);
        }
      }

      if (!property) {
        return { propertyId: null, address: null, confidence: 0, matchMethod: 'no_regrid_data' };
      }

      // Step 4: Validate that the photo coordinate falls within the parcel boundary
      if (!this.isWithinParcel(latitude, longitude, property.boundary)) {
        return { propertyId: null, address: null, confidence: 0, matchMethod: 'coordinate_outside_parcel' };
      }

      // Step 5: Compute additional confidence metrics
      const propertyCenter = turf.center(property.boundary);
      const distance = turf.distance(
        turf.point([longitude, latitude]),
        propertyCenter,
        { units: 'meters' }
      );
      let confidence = 1.0;
      if (distance > 20) confidence -= 0.2;

      if (confidence < this.MIN_TOTAL_CONFIDENCE) {
        return { propertyId: null, address: null, confidence, matchMethod: 'low_confidence' };
      }

      // Step 6: Save/update the property profile
      const propertyId = await this.updatePropertyProfile(property);

      // Return successful match result
      return {
        propertyId: String(propertyId),
        address: property.address.street,
        ownerName: property.ownerInfo.name,
        ownerCareOf: property.ownerInfo.careOf,
        parcelNumber: property.parcelNumber,
        yearBuilt: property.yearBuilt,
        propertyValue: property.propertyValue?.total,
        improvementValue: property.propertyValue?.improvements,
        landValue: property.propertyValue?.land,
        use: property.useDescription,
        zoning: property.zoning?.code,
        confidence,
        matchMethod: 'regrid_parcel_match'
      };

    } catch (error) {
      console.error("Error in findMatchingProperty:", error);
      return {
        propertyId: null,
        address: null,
        confidence: 0,
        matchMethod: 'error',
      };
    }
  }

  private getCachedProperty(key: string): RegridProperty | null {
    const cached = propertyCache.get(key);
    if (!cached) return null;

    if (Date.now() - cached.timestamp > CACHE_TTL) {
      propertyCache.delete(key);
      return null;
    }

    return cached.data;
  }

  private cachePropertyProfile(key: string, property: RegridProperty): void {
    propertyCache.set(key, {
      timestamp: Date.now(),
      data: property
    });
  }

  private async isHighDensityArea(lat: number, lng: number): Promise<boolean> {
    try {
      // Quick check for nearby parcels
      const response = await this.queryRegridProperty(lat, lng, 50, true);
      return response?.nearbyParcelCount > 3;
    } catch (error) {
      console.error("Error checking area density:", error);
      return false;
    }
  }

  private isWithinParcel(lat: number, lng: number, boundary: GeoJSON.Feature<GeoJSON.Polygon>): boolean {
    const point = turf.point([lng, lat]);
    return turf.booleanPointInPolygon(point, boundary);
  }

  private async updatePropertyProfile(property: RegridProperty): Promise<number> {
    const propertyData = {
      address: property.address.street,
      city: property.address.city,
      state: property.address.state,
      zip_code: property.address.zipCode,
      latitude: String(property.coordinates.latitude),
      longitude: String(property.coordinates.longitude),
      parcel_number: property.parcelNumber,
      year_built: property.yearBuilt,
      property_value: property.propertyValue?.total,
      improvement_value: property.propertyValue?.improvements,
      land_value: property.propertyValue?.land,
      use_description: property.useDescription,
      zoning: property.zoning?.code,
      zoning_description: property.zoning?.description,
      owner_type: this.determineOwnerType(property.ownerInfo.name),
      owner_care_of: property.ownerInfo.careOf,
      owner_mailing_street: property.ownerInfo.mailingAddress.street,
      owner_mailing_city: property.ownerInfo.mailingAddress.city,
      owner_mailing_state: property.ownerInfo.mailingAddress.state,
      owner_mailing_zip: property.ownerInfo.mailingAddress.zipCode,
      owner_mailing_country: property.ownerInfo.mailingAddress.country,
      last_owner_update: new Date(),
      ...this.parseOwnerName(property.ownerInfo.name)
    };

    // Check if property exists
    const [existingProperty] = await db
      .select()
      .from(properties)
      .where(
        and(
          eq(properties.latitude, String(property.coordinates.latitude)),
          eq(properties.longitude, String(property.coordinates.longitude))
        )
      )
      .limit(1);

    if (existingProperty) {
      await db
        .update(properties)
        .set(propertyData)
        .where(eq(properties.id, existingProperty.id));
      return existingProperty.id;
    } else {
      const [newProperty] = await db
        .insert(properties)
        .values(propertyData)
        .returning();
      return newProperty.id;
    }
  }

  private determineOwnerType(name: string): string {
    const lname = name.toLowerCase();
    if (lname.includes('llc') || lname.includes('inc') || lname.includes('corp') ||
      lname.includes('trust') || lname.includes('properties')) {
      return 'business';
    }
    if (lname.includes('city of') || lname.includes('county') ||
      lname.includes('state of') || lname.includes('department')) {
      return 'government';
    }
    return 'individual';
  }

  private parseOwnerName(name: string): {
    owner1_first_name: string;
    owner1_last_name: string;
    owner1_company: string | null;
  } {
    const ownerType = this.determineOwnerType(name);
    if (ownerType !== 'individual') {
      return {
        owner1_first_name: '',
        owner1_last_name: '',
        owner1_company: name
      };
    }

    if (name.includes(',')) {
      const [last, first] = name.split(',').map(part => part.trim());
      return {
        owner1_first_name: first,
        owner1_last_name: last,
        owner1_company: null
      };
    }

    const parts = name.trim().split(/\s+/);
    return {
      owner1_first_name: parts[0] || '',
      owner1_last_name: parts.slice(1).join(' ') || '',
      owner1_company: null
    };
  }
  private async queryRegridProperty(latitude: number, longitude: number, radius: number = 25, includeNearby: boolean = false) {
    try {
      const url = `https://app.regrid.com/api/v2/parcels/point?` +
        `lat=${latitude}&lon=${longitude}&radius=${radius}&token=${this.regridApiKey}`;

      const response = await fetch(url, {
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'CloudLens/1.0'
        }
      });

      if (!response.ok) {
        throw new Error(`Regrid API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      if (!data.features || data.features.length === 0) {
        return null;
      }

      return {
        ...data.features[0].properties,
        nearbyParcelCount: includeNearby ? data.features.length : undefined
      };
    } catch (error) {
      console.error('Error querying Regrid:', error);
      return null;
    }
  }
}

interface RegridProperty {
  address: {
    street: string;
    city: string;
    state: string;
    zipCode: string;
  };
  coordinates: {
    latitude: number;
    longitude: number;
  };
  parcelNumber: string;
  yearBuilt: number;
  propertyValue?: {
    total: number;
    improvements: number;
    land: number;
  };
  useDescription: string;
  zoning?: {
    code: string;
    description: string;
  };
  ownerInfo: {
    name: string;
    careOf?: string;
    mailingAddress: {
      street: string;
      city: string;
      state: string;
      zipCode: string;
      country: string;
    };
  };
  boundary: GeoJSON.Feature<GeoJSON.Polygon>;
  nearbyParcelCount?: number;
}

declare module 'geojson' {
  export interface Polygon {
    type: 'Polygon';
    coordinates: number[][][];
  }

  export interface Feature<T> {
    type: 'Feature';
    properties: any;
    geometry: T;
  }
}

declare module 'turf' {
  export function point(coordinates: number[]): any;
  export function booleanPointInPolygon(point: any, polygon: any): boolean;
  export function distance(point1: any, point2: any, options: { units: string }): number;
  export function center(polygon: any): any;

}