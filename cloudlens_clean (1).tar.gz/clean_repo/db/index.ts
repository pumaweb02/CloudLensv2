import { drizzle } from "drizzle-orm/neon-serverless";
import ws from "ws";
import * as schema from "@db/schema";

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

/**
 * Database configuration with optimized settings for handling large datasets
 * - Implements connection pooling
 * - Configures statement timeout
 * - Sets up WebSocket for real-time updates
 */
export const db = drizzle({
  connection: process.env.DATABASE_URL,
  schema,
  ws: ws,
  options: {
    // Optimize for large datasets
    prepared_statements: true,
    statement_timeout: 30000, // 30 seconds timeout for long-running queries
    query_timeout: 30000,
    connect_timeout: 10000,
    // Connection pool settings
    pool: {
      min: 2,
      max: 10,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 2000,
    },
  },
});

/**
 * Utility function to handle database pagination
 * @param page Page number (1-based)
 * @param pageSize Number of items per page
 * @returns Object with offset and limit values
 */
export function getPaginationParams(page: number = 1, pageSize: number = 20) {
  const offset = (page - 1) * pageSize;
  return {
    offset,
    limit: pageSize,
  };
}

/**
 * Utility function to generate optimized query filters
 * @param filters Object containing filter parameters
 * @returns Object with SQL-safe filter conditions
 */
export function generateQueryFilters(filters: Record<string, any>) {
  // Implementation will be added based on specific query requirements
  return filters;
}