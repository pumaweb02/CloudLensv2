import { PhotoViewer } from "@/components/photo-viewer";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import {
  ArrowLeft,
  Loader2,
  Wind,
  CloudRain,
  AlertTriangle,
  Save,
  MapPin,
  Trash2,
  Eye,
  Download,
  Building2,
  Users,
  Camera,
  ClipboardCheck,
  Home,
  FileText,
  Shield,
  ImageIcon,
  Sparkles,
  FileDown,
  CheckCircle2,
  XCircle,
  User,
  Copy,
  ExternalLink,
  FileEdit,
  Calendar,
  Cloud
} from "lucide-react";
import { PhotoEditor } from "@/components/photo-editor";
import { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { InlineEdit } from "@/components/inline-edit";
import { StateSelect } from "@/components/state-select";
import axios from 'axios';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ImageGallery } from "@/components/image-gallery";
import { Input } from "@/components/ui/input";
import { Calendar as CalendarIcon, Cloud as CloudIcon } from "lucide-react";
import { ReportList } from "@/components/report-list";

interface Photo {
  id: number;
  filename: string;
  originalName: string;
  uploadedAt: string;
  url: string;
  thumbnailUrl: string;
  metadata: any;
  user: any;
}

interface WeatherEvent {
  date: string;
  type: string;
  severity: string;
  description: string;
}

interface InspectionReport {
  id: number;
  createdAt: string;
  url: string;
}

interface Inspection {
  id: number;
  createdAt: string;
  notes: string;
  status: string;
  damageType: string;
  severity: string;
  report?: InspectionReport;
  photos?: Array<{
    id: number;
    editedImage: string;
    notes: string;
  }>;
}

interface PropertyData {
  id: number;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  latitude: string | null;
  longitude: string | null;
  status: string;
  owner1FirstName: string | null;
  owner1LastName: string | null;
  owner1Phone: string | null;
  owner1Email: string | null;
  owner1Company: string | null;
  parcelNumber?: string;
  yearBuilt?: number;
  propertyValue?: number;
  photos?: Photo[];
  inspections?: Inspection[];
  createdAt?: string;
  updatedAt?: string;
}

export function PropertyView() {
  const [, params] = useRoute<{ id: string }>("/property/:id");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State management
  const [selectedWeatherTypes, setSelectedWeatherTypes] = useState<string[]>([]);
  const [weatherEvents, setWeatherEvents] = useState<WeatherEvent[]>([]);
  const [isLoadingWeather, setIsLoadingWeather] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<WeatherEvent | null>(null);
  const [selectedInspection, setSelectedInspection] = useState<Inspection | null>(null);
  const [showInspectionDialog, setShowInspectionDialog] = useState(false);
  const [isLoadingRegrid, setIsLoadingRegrid] = useState(false);
  const [regridData, setRegridData] = useState<any>(null);
  const [showDateRangePicker, setShowDateRangePicker] = useState(false); // Added state for date range picker
  const [selectedPhotoIds, setSelectedPhotoIds] = useState<number[]>([]); // Added state for selected photo IDs


  // Queries
  const { data: property, isLoading, error: propertyError } = useQuery<PropertyData>({
    queryKey: [`/api/properties/${params?.id}`],
    enabled: !!params?.id,
    refetchOnMount: 'always',
    refetchOnWindowFocus: true,
    staleTime: 0,
    retry: 3
  });

  // Weather events filtering
  const filteredEvents = useMemo(() => {
    if (!Array.isArray(weatherEvents)) return [];
    return weatherEvents.filter(event =>
      selectedWeatherTypes.length === 0 || selectedWeatherTypes.includes(event.type)
    );
  }, [weatherEvents, selectedWeatherTypes]);

  // Format currency helper
  const formatCurrency = (value?: number): string => {
    if (!value) return 'N/A';
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  // Update the handleFetchRegridData function
  const handleFetchRegridData = async () => {
    if (!property) return;

    setIsLoadingRegrid(true);
    try {
      const response = await fetch(`/api/properties/${property.id}/regrid`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include'
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || 'Failed to fetch Regrid data');
      }

      const data = await response.json();

      // Invalidate the property query to refresh the data
      await queryClient.invalidateQueries([`/api/properties/${property.id}`]);

      toast({
        title: "Success",
        description: "Property data updated from Regrid"
      });
    } catch (error) {
      console.error('Error fetching Regrid data:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to fetch Regrid data"
      });
    } finally {
      setIsLoadingRegrid(false);
    }
  };

  // Effects
  useEffect(() => {
    const fetchWeatherData = async () => {
      if (!property?.latitude || !property?.longitude) return;

      setIsLoadingWeather(true);
      try {
        const response = await axios.get('/api/weather', {
          params: {
            lat: property.latitude,
            lon: property.longitude
          }
        });

        setWeatherEvents(response.data || []);
      } catch (error) {
        console.error('Error fetching weather data:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch weather data"
        });
        setWeatherEvents([]);
      } finally {
        setIsLoadingWeather(false);
      }
    };

    if (property?.latitude && property?.longitude) {
      fetchWeatherData();
    }
  }, [property?.latitude, property?.longitude, toast]);

  // Loading state
  if (isLoading || !property) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  const isPropertyComplete = Boolean(property.address && property.city && property.state && property.zipCode);
  const isOwnerComplete = Boolean(property.owner1FirstName && property.owner1LastName);

  const handleUpdateProperty = async (updates: Partial<PropertyData>) => {
    if (!property) return;

    try {
      const response = await fetch(`/api/properties/${property.id}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify(updates)
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      // Fix the query invalidation
      await queryClient.invalidateQueries({ 
        queryKey: [`/api/properties/${property.id}`] 
      });

      toast({
        title: "Success",
        description: "Property updated successfully"
      });
    } catch (error) {
      console.error('Error updating property:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to update property"
      });
    }
  };

  // Helper functions
  const getStreetViewUrl = (property: PropertyData): string => {
    if (!property.latitude || !property.longitude) {
      const formattedAddress = encodeURIComponent(
        `${property.address}, ${property.city}, ${property.state} ${property.zipCode}`
      );
      return `https://maps.googleapis.com/maps/api/streetview?size=800x400&location=${formattedAddress}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`;
    }
    return `https://maps.googleapis.com/maps/api/streetview?size=800x400&location=${property.latitude},${property.longitude}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`;
  };

  const weatherTypeOptions = ["wind", "hail", "rain", "storm"];

  const handleSaveAnnotations = async (annotations: any[], lines: any[]) => {
    try {
      const response = await fetch(`/api/properties/${property.id}/annotations`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ annotations, lines })
      });

      if (!response.ok) {
        throw new Error('Failed to save annotations');
      }

      // Invalidate cached data
      await queryClient.invalidateQueries([`/api/properties/${property.id}`]);
      toast({ title: "Success", description: "Annotations saved successfully" });
    } catch (error) {
      console.error('Error saving annotations', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : 'Failed to save annotations'
      });
    }
  };

  const loadInspectionDetails = async (inspectionId: number) => {
    try {
      const response = await fetch(`/api/inspections/${inspectionId}`);
      if (!response.ok) {
        throw new Error('Failed to load inspection details');
      }
      const data = await response.json();
      setSelectedInspection(data);
      setShowInspectionDialog(true);
    } catch (error) {
      console.error('Error loading inspection details:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load inspection details"
      });
    }
  };

  const handleExportInspectionPDF = async (inspection: Inspection) => {
    if (!property || !inspection) return;

    try {
      const response = await fetch(`/api/properties/${property.id}/inspections/${inspection.id}/report`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          property: {
            address: property.address,
            city: property.city,
            state: property.state,
            zipCode: property.zipCode,
            parcelNumber: property.parcelNumber,
            yearBuilt: property.yearBuilt?.toString(),
            propertyValue: property.propertyValue
          },
          owners: {
            primary: property.owner1FirstName && property.owner1LastName ? {
              name: `${property.owner1FirstName} ${property.owner1LastName}`,
              company: property.owner1Company,
              phone: property.owner1Phone,
              email: property.owner1Email
            } : undefined
          }
        })
      });

      if (!response.ok) {
        throw new Error('Failed to generate report');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `inspection-report-${inspection.id}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Success",
        description: "Report downloaded successfully"
      });

      // Properly invalidate the query to refresh the data
      await queryClient.invalidateQueries({
        queryKey: [`/api/properties/${property.id}`]
      });

    } catch (error) {
      console.error('Error exporting report:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to generate report"
      });
    }
  };

  const handleDeleteInspection = async (inspectionId: number) => {
    if (!property) return;

    try {
      const response = await fetch(`/api/properties/${property.id}/inspections/${inspectionId}`, {
        method: 'DELETE',
        credentials: 'include'
      });

      if (!response.ok) {
        throw new Error('Failed to delete inspection');
      }

      // Invalidate queries to refresh the inspection list
      await queryClient.invalidateQueries({
        queryKey: [`/api/properties/${property.id}`]
      });

      toast({
        title: "Success",
        description: "Inspection deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting inspection:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to delete inspection"
      });
    }
  };

  const reports = property?.inspections; // Assuming reports are the same as property.inspections

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center justify-between">
          <div className="flex items-center gap-2">
            <User className="h-6 w-6" />
            <span className="font-semibold">CloudLens</span>
          </div>
        </div>
      </header>

      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <div>
            <Button variant="ghost" onClick={() => setLocation("/")} className="mb-2">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Properties
            </Button>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold">{property.address}</h1>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => {
                  navigator.clipboard.writeText(property.address);
                  toast({
                    title: "Copied",
                    description: "Address copied to clipboard",
                  });
                }}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-muted-foreground">
              {property.city}, {property.state} {property.zipCode}
            </p>
          </div>

          <Button
            variant="outline"
            onClick={handleFetchRegridData}
            disabled={isLoadingRegrid}
          >
            {isLoadingRegrid ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Building2 className="h-4 w-4 mr-2" />
            )}
            Fetch Regrid Data
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2">
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="w-full justify-start">
                <TabsTrigger value="details" className="flex items-center gap-2">
                  Property Details
                  {isPropertyComplete && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                </TabsTrigger>
                <TabsTrigger value="photos" className="flex items-center gap-2">
                  Photos ({property?.photos?.length || 0})
                </TabsTrigger>
                <TabsTrigger value="inspections" className="flex items-center gap-2">
                  Inspections ({reports?.length || property?.inspections?.length || 0})
                </TabsTrigger>
                <TabsTrigger value="owners" className="flex items-center gap-2">
                  Owners
                  {isOwnerComplete && <CheckCircle2 className="w-4 h-4 text-green-500" />}
                </TabsTrigger>
                <TabsTrigger value="documents">Documents</TabsTrigger>
                <TabsTrigger value="actions">Actions</TabsTrigger>
              </TabsList>

              <TabsContent value="details" className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Property Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-6">
                      {/* Basic Property Info */}
                      <div>
                        <h3 className="text-sm font-medium mb-2">Basic Information</h3>
                        <div className="space-y-2">
                          <div>
                            <label className="text-sm text-muted-foreground">Address</label>
                            <div className="font-medium">{property.address}</div>
                          </div>
                          <div>
                            <label className="text-sm text-muted-foreground">Owner</label>
                            <div className="font-medium">
                              {property.owner1FirstName} {property.owner1LastName}
                              {property.owner1Company && (
                                <span className="text-muted-foreground ml-2">({property.owner1Company})</span>
                              )}
                            </div>
                          </div>
                          <div>
                            <label className="text-sm text-muted-foreground">Parcel Number</label>
                            <div className="font-medium">{property.parcelNumber || regridData?.parcelNumber || 'N/A'}</div>
                          </div>
                        </div>
                      </div>

                      {/* Property Details */}
                      <div>
                        <h3 className="text-sm font-medium mb-2">Property Details</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm text-muted-foreground">Year Built</label>
                            <div className="font-medium">{property.yearBuilt || regridData?.yearBuilt || 'N/A'}</div>
                          </div>
                          <div>
                            <label className="text-sm text-muted-foreground">Property Value</label>
                            <div className="font-medium">
                              {formatCurrency(property.propertyValue || regridData?.propertyValue)}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Geographic Data */}
                      <div>
                        <h3 className="text-sm font-medium mb-2">Geographic Data</h3>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm text-muted-foreground">Latitude</label>
                            <div className="font-medium">{property.latitude || 'N/A'}</div>
                          </div>
                          <div>
                            <label className="text-sm text-muted-foreground">Longitude</label>
                            <div className="font-medium">{property.longitude || 'N/A'}</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Date Range Picker Dialog */}
                <Dialog open={showDateRangePicker} onOpenChange={setShowDateRangePicker}>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Filter Weather Events</DialogTitle>
                      <DialogDescription>
                        Select a date range to filter weather events
                      </DialogDescription>
                    </DialogHeader>
                    <div className="grid gap-4">
                      <div className="grid gap-2">
                        <Label>Start Date</Label>
                        <Input
                          type="date"
                          onChange={(e) => {
                            // TODO: Implement date filtering
                          }}
                        />
                      </div>
                      <div className="grid gap-2">
                        <Label>End Date</Label>
                        <Input
                          type="date"
                          onChange={(e) => {
                            // TODO: Implement date filtering
                          }}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button onClick={() => setShowDateRangePicker(false)}>
                        Apply
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </TabsContent>

              <TabsContent value="photos" className="mt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Property Photos</h3>
                    <Button
                      variant="default"
                      onClick={() => {
                        if (!property?.photos?.length) {
                          toast({
                            title: "No Photos Available",
                            description: "Please upload photos before creating an inspection report.",
                            variant: "destructive"
                          });
                          return;
                        }
                        const photoIds = property.photos.map(p => p.id).join(',');
                        setLocation(`/property/${property.id}/inspection/new?photos=${photoIds}`);
                      }}
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Start Inspection Report
                    </Button>
                  </div>
                  <ImageGallery
                    photos={property.photos || []}
                    selectedIds={selectedPhotoIds}
                    onSelectionChange={setSelectedPhotoIds}
                    propertyId={property.id}
                  />
                </div>
              </TabsContent>

              <TabsContent value="inspections" className="mt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-semibold">Property Inspections</h3>
                    <Button
                      variant="default"
                      onClick={() => {
                        if (!property?.photos?.length) {
                          toast({
                            title: "No Photos Available",
                            description: "Please upload photos before creating an inspection report.",
                            variant: "destructive"
                          });
                          return;
                        }
                        setLocation(`/property/${property.id}/inspection/new?photos=${property.photos.map(p => p.id).join(',')}`);
                      }}
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Start New Inspection
                    </Button>
                  </div>

                  <ReportList propertyId={property.id} />
                </div>
              </TabsContent>

              <TabsContent value="owners">
                <Card>
                  <CardHeader>
                    <CardTitle>Owner Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium">First Name</label>
                          <div className="font-medium">{property.owner1FirstName || 'N/A'}</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Last Name</label>
                          <div className="font-medium">{property.owner1LastName || 'N/A'}</div>
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Company</label>
                        <div className="font-medium">{property.owner1Company || 'N/A'}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="text-sm font-medium">Phone</label>
                          <div className="font-medium">{property.owner1Phone || 'N/A'}</div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Email</label>
                          <div className="font-medium">{property.owner1Email || 'N/A'}</div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="documents">
                <div className="p-4 text-center text-muted-foreground">
                  Document management coming soon
                </div>
              </TabsContent>
              <TabsContent value="actions">
                <Card>
                  <CardHeader>
                    <CardTitle>Activity Log</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-[600px]">
                      <div className="space-y-4">
                        {property?.inspections?.map((inspection) => (
                          <div key={inspection.id} className="flex gap-4 items-start">
                            <div className="w-4 h-4 mt-1 rounded-full bg-primary" />
                            <div>
                              <p className="font-medium">
                                Inspection {inspection.status === 'completed' ? 'Completed' : 'Created'}
                              </p>
                              <p className="text-sm text-muted-foreground">
                                {new Date(inspection.createdAt).toLocaleString()}
                              </p>
                              <p className="text-sm mt-1">
                                {inspection.notes}
                              </p>
                            </div>
                          </div>
                        ))}
                        <div className="flex gap-4 items-start">
                          <div className="w-4 h-4 mt-1 rounded-full bg-primary" />
                          <div>
                            <p className="font-medium">Property Created</p>
                            <p className="text-sm text-muted-foreground">
                              {new Date(property.createdAt || '').toLocaleString()}
                            </p>
                          </div>
                        </div>
                      </div>
                    </ScrollArea>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Street View</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="relative aspect-video">
                  <img
                    src={getStreetViewUrl(property)}
                    alt="Street View"
                    className="w-full h-full object-cover rounded"
                  />
                </div>
                <div className="mt-2 text-xs space-y-1">
                  <p className="text-muted-foreground">
                    Created: {new Date(property.createdAt || '').toLocaleString()}
                  </p>
                  {property.updatedAt && (
                    <p className="text-muted-foreground">
                      Last edited: {new Date(property.updatedAt).toLocaleString()}
                    </p>
                  )}
                  <a
                    href={`https://www.google.com/maps?layer=c&cbll=${property.latitude},${property.longitude}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary"
                  >
                    <ExternalLink className="h-4 w-4" />
                    View in Street View
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Quick Summary Card */}
            <Card className="mt-4">
              <CardHeader>
                <CardTitle>Quick Summary</CardTitle>
              </CardHeader>
              <CardContent>
                {/* Property Summary Stats */}
                <div className="space-y-2 mb-6">
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="text-sm font-medium">Total Value</label>
                      <div className="text-2xl font-bold">
                        {formatCurrency(property.propertyValue || regridData?.propertyValue)}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Year Built</label>
                      <div className="text-2xl font-bold">
                        {property.yearBuilt || regridData?.yearBuilt || 'N/A'}
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Status</label>
                      <div>
                        <Badge variant={property.status === 'completed' ? 'default' : 'secondary'}>
                          {property.status}
                        </Badge>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="text-sm font-medium">Photos</label>
                        <div className="font-medium">{property?.photos?.length || 0}</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Inspections</label>
                        <div className="font-medium">{property?.inspections?.length || 0}</div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Recent Weather Events - Separate Section */}
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-4">
                    <CardTitle className="text-base">Recent Weather Events</CardTitle>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowDateRangePicker(true)}
                      className="h-7 px-2"
                    >
                      <CalendarIcon className="h-4 w-4" />                    </Button>
                  </div>

                  {/* Weather Type Filters */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {weatherTypeOptions.map((type) => (
                      <Button
                        key={type}
                        variant={selectedWeatherTypes.includes(type) ? "default" : "outline"}
                        size="sm"
                        onClick={() => {
                          setSelectedWeatherTypes((prev) =>
                            prev.includes(type)
                              ? prev.filter((t) => t !== type)
                              : [...prev, type]
                          );
                        }}
                        className="h-7 px-2"
                      >
                        {type === 'wind' && <Wind className="w-3 h3 h-3 mr-1" />}
                        {type === 'rain' && <CloudRain className="w-3 h-3 mr-1" />}
                        {type === 'hail' && <AlertTriangle className="w-3 h-3 mr-1" />}
                        {type === 'storm' && <CloudIcon className="w-3 h-3 mr-1" />}
                        {type}
                      </Button>
                    ))}
                  </div>

                  {/* Events List */}
                  <div className="space-y-1 max-h-[200px] overflow-y-auto border rounded-md p-2">
                    {isLoadingWeather ? (
                      <div className="flex items-center justify-center py-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                      </div>
                    ) : filteredEvents.length > 0 ? (
                      filteredEvents.map((event, index) => (
                        <div
                          key={`${event.date}-${index}`}
                          className="flex items-center justify-between p-2 hover:bg-accent rounded-sm"
                        >
                          <Badge variant={
                            event.severity === 'high' ? 'destructive' :
                              event.severity === 'medium' ? 'default' : 'default'
                          }>
                            {event.type}
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            {new Date(event.date).toLocaleDateString()}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-2 text-sm text-muted-foreground">
                        No weather events found
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {showInspectionDialog && selectedInspection && (
          <Dialog open={showInspectionDialog} onOpenChange={setShowInspectionDialog}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Inspection Details</DialogTitle>
                <DialogDescription>
                  Created: {new Date(selectedInspection.createdAt).toLocaleString()}
                  <br />
                  Status: {selectedInspection.status}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label>Damage Type</Label>
                  <div className="text-muted-foreground">{selectedInspection.damageType}</div>
                </div>
                <div>
                  <Label>Severity</Label>
                  <div className="text-muted-foreground">{selectedInspection.severity}</div>
                </div>
                <div>
                  <Label>Notes</Label>
                  <div className="text-muted-foreground whitespace-pre-wrap">{selectedInspection.notes}</div>
                </div>
              </div>
              <DialogFooter><div className="flex justify-between w-full">
                  <Button
                    variant="outline"
                    onClick={() => handleExportInspectionPDF(selectedInspection)}
                  >
                    <FileDown className="w-4 h-4 mr-2" />
                    Export PDF
                  </Button>
                  <div className="flex gap-2">
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => {
                        if (selectedInspection?.id) {
                          handleDeleteInspection(selectedInspection.id);
                        }
                      }}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                    <Button onClick={() => setShowInspectionDialog(false)}>Close</Button>
                  </div>
                </div>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
}

export default PropertyView;

const handleUpdateOwner2LastName = async (value: string) => {
  try {
    const response = await fetch(`/api/properties/${params?.id}/owner2LastName`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lastName: value }),
      credentials: "include",
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    await queryClient.invalidateQueries({ queryKey: ['/api/properties'] });

    toast({
      title: "Success",
      description: "Owner 2 last name updated successfully",
    });
  } catch (error) {
    toast({
      variant: "destructive",
      title: "Error",
      description: error instanceof Error ? error.message : "Failed to update owner",
    });
  }
};


const handleDeleteInspection = async (inspectionId: number) => {
  try {
    const response = await fetch(`/api/properties/${params?.id}/inspections/${inspectionId}`, {
      method: 'DELETE',
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error(await response.text());
    }

    await queryClient.invalidateQueries({ queryKey: [`/api/properties/${params?.id}`] });
    toast({ title: 'Success', description: 'Inspection deleted successfully' });
  } catch (error) {
    console.error('Error deleting inspection:', error);
    toast({
      variant: 'destructive',
      title: 'Error',
      description: error instanceof Error ? error.message : 'Failed to delete inspection',
    });
  }
};

const handleContinueDraft = async (inspection: any) => {
  setManualInspection({ ...inspection, photos: inspection.photos.map((photo: any) => ({ ...photo, annotations: photo.annotations })) });
  setCurrentEditingPhoto(inspection.photos[0].photoId);
  setShowPhotoEditor(true);
};

const onSaveInspection = async (photoId: number, data: any) => {
  try {
    const response = await fetch(`/api/api/properties/${property?.id}/photos/${photoId}/annotations`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify({
        annotations: data.annotations,
        notes: data.notes,
      }),
    });
    if (!response.ok) {
      throw new Error(await response.text());
    }
    await queryClient.invalidateQueries([`/api/properties/${property?.id}`]);
    toast({ title: "Success", description: "Annotations saved successfully" });
  } catch (error) {
    console.error('Error saving annotations', error);
    toast({ variant: "destructive", title: "Error", description: error instanceof Error ? error.message : "Failed tosave annotations" });
  }
};

interface DateRange {
  from: Date | null;
  to: Date | null;
}

// Placeholder functions -  replace with actual implementations
const handlePropertyError = (error: any) => {
  //Implementation for handling property update errors
};

const handleReportGeneration = (inspection: any) => {
  //Implementation for generating report
};

const handleSaveReport = () => {
  //Implementation for saving report
};

const setManualInspection = (inspection: any) => {
  //Implementation for setting manual inspection
};

const setCurrentEditingPhoto = (photoId: number) => {
  //Implementation for setting current editing photo
};

const setShowPhotoEditor = (show: boolean) => {
  //Implementation for showing/hiding photo editor
};

const analyzedPhotos = []; // Replace with actual data if needed.

const showReportPreview = false; //Replace with actual state if needed.
const setShowReportPreview = () => { }; //Replace with actual function if needed.


const CompletionIndicator = ({ isComplete }: { isComplete: boolean }) => (
  <span className={`ml-2 rounded-full px-2 py-0.5 text-xs font-medium ${isComplete ? 'bg-green-500 text-white' : 'bg-gray-300 text-gray-600'}`}>
    {isComplete ? 'Complete' : 'Incomplete'}
  </span>
);


// Added StreetViewLink type definition (assuming it exists elsewhere)
interface StreetViewLinkProps {
  address: string;
  lat: number | null;
  lng: number | null;
}

const StreetViewLink: React.FC<StreetViewLinkProps> = ({ address, lat, lng }) => {
  //Implementation for StreetView Link
  return <></>;
};