import { format } from 'date-fns';

export interface InspectionData {
  photoId: number;
  editedImage: string;
  damageType: string;
  severity: string;
  notes: string;
  weather?: {
    temperature?: number;
    conditions?: string;
    windSpeed?: number;
    precipitation?: number;
  };
}

export interface PropertyReport {
  property: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
    parcelNumber?: string;
    yearBuilt?: string;
    propertyUse?: string;
    propertyValue?: number;
    landValue?: number;
    improvementValue?: number;
  };
  inspectionData: InspectionData[];
}

export async function generateInspectionReport(propertyId: number, inspectionId: number): Promise<string> {
  try {
    console.log('Requesting PDF generation from server...');

    const response = await fetch(`/api/properties/${propertyId}/inspections/${inspectionId}/report`, {
      method: 'GET',
      headers: {
        'Accept': 'application/pdf',
      },
    });

    if (!response.ok) {
      throw new Error(`Failed to generate report: ${response.statusText}`);
    }

    // Create a blob from the PDF stream
    const blob = await response.blob();

    // Create a URL for the blob
    const url = window.URL.createObjectURL(blob);

    // Trigger download with a meaningful filename
    const a = document.createElement('a');
    a.href = url;
    a.download = `CloudLens-Assessment-${propertyId}-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);

    return url;
  } catch (error) {
    console.error('Error generating PDF:', error);
    throw error;
  }
}