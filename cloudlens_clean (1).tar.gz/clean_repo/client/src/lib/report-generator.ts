import { format } from 'date-fns';
import puppeteer from 'puppeteer';
import Handlebars from 'handlebars';
import { Property } from '@db/schema';

interface PropertyReport {
  property: {
    address: string;
    city: string;
    state: string;
    zipCode: string;
    parcelNumber?: string;
    yearBuilt?: string;
    propertyValue?: number;
    coordinates: {
      latitude: number;
      longitude: number;
    }
  };
  owners: {
    primary?: {
      name?: string;
      company?: string;
      phone?: string;
      email?: string;
    };
  };
  inspectionData: {
    propertyId: number;
    photos: Array<{
      photoId: number;
      editedImage: string;
      damageType: string;
      severity: string;
      notes: string;
    }>;
  };
}

// Register Handlebars helpers
Handlebars.registerHelper('formatDate', (date: string) => {
  return format(new Date(date), 'MMMM d, yyyy');
});

Handlebars.registerHelper('currentYear', () => {
  return new Date().getFullYear();
});

Handlebars.registerHelper('severityText', (severity: string) => {
  switch (severity) {
    case "high":
      return "CRITICAL - Immediate Action Required";
    case "medium":
      return "SIGNIFICANT - Prompt Attention Needed";
    case "low":
      return "MINOR - Monitoring Recommended";
    default:
      return "Assessment Required";
  }
});

Handlebars.registerHelper('damageDescription', (type: string) => {
  switch (type) {
    case "wind":
      return "Storm-Related Wind Damage Patterns Identified";
    case "hail":
      return "Storm-Induced Hail Impact Patterns Detected";
    case "other":
      return "Storm-Related Structural Anomalies Observed";
    default:
      return "Additional Assessment Recommended";
  }
});

export async function generateInspectionReport(report: PropertyReport): Promise<Buffer> {
  try {
    // Read the template
    const templatePath = new URL('./templates/inspection-report.hbs', import.meta.url);
    const template = await fetch(templatePath).then(res => res.text());

    // Compile template
    const compiledTemplate = Handlebars.compile(template);

    // Prepare data for the template
    const defaultPhoto = report.inspectionData.photos[0];
    const remainingPhotos = report.inspectionData.photos.slice(1);

    const templateData = {
      date: new Date().toISOString(),
      referenceId: Date.now().toString().slice(-6),
      propertyAddress: `${report.property.address}, ${report.property.city}, ${report.property.state} ${report.property.zipCode}`,
      defaultPhoto: {
        ...defaultPhoto,
        url: defaultPhoto.editedImage,
      },
      remainingPhotos: remainingPhotos.map(photo => ({
        ...photo,
        url: photo.editedImage,
      })),
    };

    // Generate HTML
    const html = compiledTemplate(templateData);

    // Launch Puppeteer with specific settings for professional PDF generation
    const browser = await puppeteer.launch({
      args: ['--no-sandbox', '--disable-setuid-sandbox'],
    });

    const page = await browser.newPage();

    // Set viewport to Letter size (8.5 × 11 inches at 96 DPI)
    await page.setViewport({
      width: 816, // 8.5 inches at 96 DPI
      height: 1056, // 11 inches at 96 DPI
      deviceScaleFactor: 2,
    });

    // Set content and wait for everything to load
    await page.setContent(html, {
      waitUntil: ['networkidle0', 'load', 'domcontentloaded'],
    });

    // Wait for all images to load
    await page.evaluate(async () => {
      const selectors = Array.from(document.getElementsByTagName('img'));
      await Promise.all(selectors.map(img => {
        if (img.complete) return;
        return new Promise((resolve, reject) => {
          img.addEventListener('load', resolve);
          img.addEventListener('error', reject);
        });
      }));
    });

    // Generate PDF with professional settings
    const pdf = await page.pdf({
      format: 'Letter', // US Letter size
      printBackground: true,
      margin: {
        top: '0.5in',
        right: '0.5in',
        bottom: '0.5in',
        left: '0.5in',
      },
      displayHeaderFooter: false, // We handle headers/footers in HTML
      preferCSSPageSize: true,
    });

    await browser.close();
    return Buffer.from(pdf);
  } catch (error) {
    console.error('Error generating inspection report:', error);
    throw error;
  }
}