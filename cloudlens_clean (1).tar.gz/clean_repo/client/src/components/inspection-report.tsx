import React from "react";
import { Document, Page, Text, View, StyleSheet, Image } from "@react-pdf/renderer";

const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: "#fff",
    padding: 0,
  },
  contentWrapper: {
    padding: "72pt 60pt",
    flex: 1,
  },
  header: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: "#1a365d",
    padding: "24pt 60pt",
    marginBottom: "36pt",
  },
  headerContent: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerLeft: {
    flexDirection: "column",
  },
  headerRight: {
    flexDirection: "column",
    alignItems: "flex-end",
  },
  logo: {
    fontSize: 24,
    fontFamily: "Helvetica-Bold",
    color: "#ffffff",
  },
  reportType: {
    fontSize: 16,
    color: "#ffffff",
    marginTop: 4,
    fontFamily: "Helvetica",
  },
  subtitle: {
    fontSize: 10,
    color: "#ffffff",
    opacity: 0.9,
    marginTop: 2,
  },
  mainContent: {
    marginTop: "72pt",
  },
  propertyDetails: {
    backgroundColor: "#f8fafc",
    padding: "16pt",
    borderRadius: 4,
    marginBottom: "24pt",
    borderWidth: 1,
    borderColor: "#e2e8f0",
  },
  detailsTitle: {
    fontSize: 14,
    fontFamily: "Helvetica-Bold",
    color: "#1a365d",
    marginBottom: 8,
  },
  detailsText: {
    fontSize: 10,
    color: "#334155",
    marginBottom: 4,
    fontFamily: "Helvetica",
  },
  imageSection: {
    marginBottom: "24pt",
  },
  imageBorder: {
    borderWidth: 1,
    borderColor: "#e2e8f0",
    padding: "16pt",
    borderRadius: 4,
  },
  imageTitle: {
    fontSize: 14,
    fontFamily: "Helvetica-Bold",
    color: "#1a365d",
    marginBottom: 12,
  },
  image: {
    width: "100%",
    height: "400pt",
    objectFit: "contain",
    marginVertical: "12pt",
  },
  analysisBox: {
    backgroundColor: "#f1f5f9",
    padding: "12pt",
    borderRadius: 4,
    marginTop: "12pt",
  },
  analysisGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    marginTop: "8pt",
  },
  analysisColumn: {
    width: "50%",
    marginBottom: "8pt",
  },
  analysisLabel: {
    fontSize: 10,
    fontFamily: "Helvetica-Bold",
    color: "#1a365d",
    marginBottom: 2,
  },
  analysisText: {
    fontSize: 10,
    color: "#334155",
    fontFamily: "Helvetica",
  },
  footer: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: "16pt 60pt",
    borderTopWidth: 1,
    borderColor: "#e2e8f0",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#f8fafc",
  },
  footerText: {
    fontSize: 8,
    color: "#64748b",
    fontFamily: "Helvetica",
  },
  pageNumber: {
    fontSize: 8,
    color: "#64748b",
    fontFamily: "Helvetica",
  },
});

interface InspectionReportProps {
  propertyAddress: string;
  date: string;
  photos: Array<{
    id: number;
    url: string;
    damageType: string;
    severity: string;
    notes?: string;
  }>;
}

const getSeverityText = (severity: string) => {
  switch (severity.toLowerCase()) {
    case "high":
      return "CRITICAL - Immediate Action Required";
    case "medium":
      return "SIGNIFICANT - Prompt Attention Needed";
    case "low":
      return "MINOR - Monitoring Recommended";
    default:
      return "Assessment Required";
  }
};

const getDamageDescription = (type: string) => {
  switch (type.toLowerCase()) {
    case "wind":
      return "Storm-Related Wind Damage Patterns Identified";
    case "hail":
      return "Storm-Induced Hail Impact Patterns Detected";
    case "water":
      return "Water Damage or Moisture Infiltration Detected";
    default:
      return "Storm-Related Structural Anomalies Observed";
  }
};

export function InspectionReport({ propertyAddress, date, photos }: InspectionReportProps) {
  return (
    <Document>
      {photos.map((photo, index) => (
        <Page key={photo.id} size="LETTER" style={styles.page}>
          {/* Fixed Header */}
          <View style={styles.header}>
            <View style={styles.headerContent}>
              <View style={styles.headerLeft}>
                <Text style={styles.logo}>CloudLens™</Text>
                <Text style={styles.reportType}>Aerial Storm Assessment Report</Text>
              </View>
              <View style={styles.headerRight}>
                <Text style={styles.subtitle}>Report Generated: {date}</Text>
                <Text style={styles.subtitle}>Reference: CL-{Date.now().toString().slice(-6)}</Text>
              </View>
            </View>
          </View>

          {/* Main Content with Proper Spacing */}
          <View style={styles.contentWrapper}>
            <View style={styles.mainContent}>
              {/* Property Details - Only on first page */}
              {index === 0 && (
                <View style={styles.propertyDetails}>
                  <Text style={styles.detailsTitle}>PROPERTY INFORMATION</Text>
                  <Text style={styles.detailsText}>Location: {propertyAddress}</Text>
                  <Text style={styles.detailsText}>Assessment Type: Advanced Aerial Drone Survey</Text>
                  <Text style={styles.detailsText}>Analysis Method: High-Resolution Aerial Imaging</Text>
                </View>
              )}

              {/* Image Analysis Section */}
              <View style={styles.imageSection}>
                <View style={styles.imageBorder}>
                  <Text style={styles.imageTitle}>
                    {index === 0 ? "Primary Assessment Image" : `Additional Analysis Area ${index + 1}`}
                  </Text>
                  <Image src={photo.url} style={styles.image} />
                  <View style={styles.analysisBox}>
                    <View style={styles.analysisGrid}>
                      <View style={styles.analysisColumn}>
                        <Text style={styles.analysisLabel}>Damage Classification:</Text>
                        <Text style={styles.analysisText}>
                          {getDamageDescription(photo.damageType)}
                        </Text>
                      </View>
                      <View style={styles.analysisColumn}>
                        <Text style={styles.analysisLabel}>Severity Assessment:</Text>
                        <Text style={styles.analysisText}>
                          {getSeverityText(photo.severity)}
                        </Text>
                      </View>
                    </View>
                    {photo.notes && (
                      <View style={{ marginTop: 8 }}>
                        <Text style={styles.analysisLabel}>Technical Notes:</Text>
                        <Text style={styles.analysisText}>{photo.notes}</Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            </View>
          </View>

          {/* Fixed Footer */}
          <View style={styles.footer}>
            <Text style={styles.footerText}>
              CloudLens™ Professional Assessment Services | 24/7 Support: 1-800-855-2562
            </Text>
            <Text style={styles.pageNumber}>
              Page {index + 1} of {photos.length}
            </Text>
          </View>
        </Page>
      ))}
    </Document>
  );
}

export default InspectionReport;