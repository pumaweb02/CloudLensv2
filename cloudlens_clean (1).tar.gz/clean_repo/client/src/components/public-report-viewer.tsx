import React, { useState, useEffect, useRef } from 'react';
import { useRoute } from 'wouter';
import { APIProvider, Map as GoogleMap, Marker } from '@vis.gl/react-google-maps';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Map as MapIcon, Image as ImageIcon } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface PublicReportProps {
  reportHash: string;
  initialLat?: number;
  initialLng?: number;
  initialZoom?: number;
  enableAnimation?: boolean;
}

interface MapAnimation {
  duration: number;
  startZoom: number;
  endZoom: number;
  easing: (t: number) => number;
}

export function PublicReportViewer({ 
  reportHash,
  initialLat,
  initialLng,
  initialZoom = 19,
  enableAnimation = true
}: PublicReportProps) {
  const [reportData, setReportData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'map' | 'photos'>('map');
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);
  const [mapZoom, setMapZoom] = useState(enableAnimation ? 0 : initialZoom);
  const [isAnimating, setIsAnimating] = useState(false);
  const mapRef = useRef<google.maps.Map | null>(null);
  const animationFrameRef = useRef<number>();

  // Fetch report data
  useEffect(() => {
    const fetchReport = async () => {
      try {
        const response = await fetch(`/api/reports/${reportHash}`);
        if (!response.ok) throw new Error('Report not found');
        const data = await response.json();
        setReportData(data);
        if (enableAnimation) {
          setIsAnimating(true);
        }
      } catch (err: any) {
        setError(err.message || 'Failed to load report');
      } finally {
        setLoading(false);
      }
    };

    fetchReport();
  }, [reportHash]);

  // Handle aerial view animation
  useEffect(() => {
    if (!isAnimating || !mapRef.current) return;

    const animation: MapAnimation = {
      duration: 3000,
      startZoom: 0,
      endZoom: initialZoom,
      easing: (t: number) => t * (2 - t) // Ease out quad
    };

    let startTime: number | null = null;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / animation.duration, 1);
      const easedProgress = animation.easing(progress);

      const currentZoom = animation.startZoom + 
        (animation.endZoom - animation.startZoom) * easedProgress;

      setMapZoom(currentZoom);

      if (progress < 1) {
        animationFrameRef.current = requestAnimationFrame(animate);
      } else {
        setIsAnimating(false);
        setTimeout(() => setCurrentView('photos'), 1000);
      }
    };

    animationFrameRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isAnimating, initialZoom]);

  // Handle automatic photo slideshow
  useEffect(() => {
    if (currentView !== 'photos' || !reportData?.photos?.length) return;

    const interval = setInterval(() => {
      setCurrentPhotoIndex(current => 
        current === reportData.photos.length - 1 ? 0 : current + 1
      );
    }, 5000);

    return () => clearInterval(interval);
  }, [currentView, reportData?.photos]);

  if (loading) {
    return <div className="flex items-center justify-center min-h-screen">
      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
    </div>;
  }

  if (error || !reportData) {
    return <div className="flex items-center justify-center min-h-screen">
      <Card>
        <CardContent className="p-6">
          <p className="text-destructive">Error loading report: {error}</p>
        </CardContent>
      </Card>
    </div>;
  }

  const handleMapLoad = (map: google.maps.Map) => {
    mapRef.current = map;
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto py-6">
        <Card>
          <CardHeader>
            <CardTitle>Property Inspection Report</CardTitle>
            <p className="text-muted-foreground">
              {reportData.property.address}
            </p>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-4">
              <Button
                variant={currentView === 'map' ? 'default' : 'outline'}
                onClick={() => setCurrentView('map')}
                disabled={isAnimating}
              >
                <MapIcon className="w-4 h-4 mr-2" />
                Aerial View
              </Button>
              <Button
                variant={currentView === 'photos' ? 'default' : 'outline'}
                onClick={() => setCurrentView('photos')}
                disabled={isAnimating}
              >
                <ImageIcon className="w-4 h-4 mr-2" />
                Inspection Photos
              </Button>
            </div>

            {currentView === 'map' && (
              <div className={cn(
                "h-[600px] rounded-lg overflow-hidden transition-opacity duration-500",
                isAnimating ? "opacity-90" : "opacity-100"
              )}>
                <APIProvider apiKey={import.meta.env.VITE_GOOGLE_MAPS_API_KEY || ''}>
                  <GoogleMap
                    zoom={mapZoom}
                    center={{ lat: initialLat || 0, lng: initialLng || 0 }}
                    mapTypeId={google.maps.MapTypeId.SATELLITE}
                    gestureHandling={isAnimating ? "none" : "greedy"}
                    disableDefaultUI={true}
                    onBoundsChanged={handleMapLoad}
                  >
                    <Marker position={{ lat: initialLat || 0, lng: initialLng || 0 }} />
                  </GoogleMap>
                </APIProvider>
              </div>
            )}

            {currentView === 'photos' && reportData.photos?.length > 0 && (
              <div className="space-y-4">
                <div className="relative aspect-video rounded-lg overflow-hidden">
                  <img
                    src={reportData.photos[currentPhotoIndex].url}
                    alt={`Inspection photo ${currentPhotoIndex + 1}`}
                    className="absolute inset-0 w-full h-full object-contain"
                  />
                </div>
                <div className="flex justify-between items-center">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPhotoIndex(i => Math.max(0, i - 1))}
                    disabled={currentPhotoIndex === 0}
                  >
                    <ChevronLeft className="w-4 h-4 mr-2" />
                    Previous
                  </Button>
                  <span className="text-sm text-muted-foreground">
                    Photo {currentPhotoIndex + 1} of {reportData.photos.length}
                  </span>
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPhotoIndex(i => 
                      Math.min(reportData.photos.length - 1, i + 1)
                    )}
                    disabled={currentPhotoIndex === reportData.photos.length - 1}
                  >
                    Next
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </div>
                <ScrollArea className="h-[200px] rounded-md border p-4">
                  <div>
                    <h3 className="font-semibold mb-2">Inspection Notes</h3>
                    <p className="text-sm text-muted-foreground">
                      {reportData.photos[currentPhotoIndex].notes}
                    </p>
                  </div>
                </ScrollArea>

                {/* Call to Action Section */}
                <div className="mt-8 p-6 bg-primary/5 rounded-lg">
                  <h3 className="text-xl font-semibold mb-2">Schedule Property Inspection</h3>
                  <p className="text-muted-foreground mb-4">
                    Our experts can help assess the damage and work with your insurance provider.
                  </p>
                  <Button size="lg" className="w-full sm:w-auto">
                    Contact Us Now
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}