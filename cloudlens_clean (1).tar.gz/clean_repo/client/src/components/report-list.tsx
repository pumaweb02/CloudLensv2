import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { FileText, Share2, Loader2, Download, FileEdit } from "lucide-react";
import { format } from "date-fns";
import { toast } from "@/hooks/use-toast";

interface Report {
  id: number;
  propertyId: number;
  status: "draft" | "completed";
  damageType: string;
  severity: string;
  createdAt: string;
  completedAt: string | null;
  shareableLink?: string;
}

interface ReportListProps {
  propertyId: number;
}

export function ReportList({ propertyId }: ReportListProps) {
  const { data: reports, isLoading } = useQuery<Report[]>({
    queryKey: [`/api/properties/${propertyId}/inspections`],
    enabled: !!propertyId,
  });

  const handleShare = async (reportId: number) => {
    try {
      const response = await fetch(`/api/properties/${propertyId}/inspections/${reportId}/share`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });

      if (!response.ok) throw new Error("Failed to create share link");

      const data = await response.json();
      const shareableUrl = `${window.location.origin}/public/report/${data.shareToken}`;

      await navigator.clipboard.writeText(shareableUrl);
      toast({
        title: "Share link copied!",
        description: "The report link has been copied to your clipboard.",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create share link"
      });
    }
  };

  const handleDownload = async (reportId: number) => {
    try {
      const response = await fetch(`/api/properties/${propertyId}/inspections/${reportId}/report`, {
        method: 'GET',
        headers: {
          'Accept': 'application/pdf',
        },
        credentials: 'include'
      });

      if (!response.ok) {
        console.error('Download failed with status:', response.status);
        throw new Error('Failed to download report');
      }

      // Get the blob directly from response
      const blob = await response.blob();

      // Verify blob type
      if (blob.type !== 'application/pdf') {
        console.error('Invalid blob type:', blob.type);
        throw new Error('Invalid response format');
      }

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = `inspection-report-${reportId}.pdf`;

      // Trigger download
      document.body.appendChild(a);
      a.click();

      // Cleanup
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);

      toast({
        title: "Success",
        description: "Report downloaded successfully"
      });
    } catch (error) {
      console.error('Download error:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to download report"
      });
    }
  };

  const handleEditDraft = async (reportId: number) => {
    window.location.href = `/property/${propertyId}/inspection/${reportId}/edit`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-6">
        <Loader2 className="w-6 h-6 animate-spin" />
      </div>
    );
  }

  if (!reports?.length) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No inspection reports available</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {reports.map((report) => (
        <Card key={report.id}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <span>
                Inspection Report #{report.id}
                <span className={`ml-2 text-sm ${
                  report.status === "completed" ? "text-green-500" : "text-yellow-500"
                }`}>
                  ({report.status})
                </span>
              </span>
              <div className="flex gap-2">
                {report.status === "draft" ? (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEditDraft(report.id)}
                  >
                    <FileEdit className="w-4 h-4 mr-2" />
                    Edit Draft
                  </Button>
                ) : (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownload(report.id)}
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleShare(report.id)}
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </>
                )}
              </div>
            </CardTitle>
            <CardDescription>
              Created on {format(new Date(report.createdAt), "PPP")}
              {report.completedAt &&
                ` • Completed on ${format(new Date(report.completedAt), "PPP")}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium">Damage Type</p>
                <p className="text-sm text-muted-foreground capitalize">
                  {report.damageType}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium">Severity</p>
                <p className="text-sm text-muted-foreground capitalize">
                  {report.severity}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}